Duarte Fragoso n2231712
Gonçalo Neto n2231685
Rodrigo Borges n2231711