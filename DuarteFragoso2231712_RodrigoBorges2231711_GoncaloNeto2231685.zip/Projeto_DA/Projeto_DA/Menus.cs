﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DA
{
    public partial class Menus : Form
    {
        string connectionString = String.Format(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\rodri\Desktop\Projeto_DA\Projeto_DA\Database1.mdf;Integrated Security = True");
        public Menus()
        {
            InitializeComponent();
            LoadMenus();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Adicionar_Menu_Click(object sender, EventArgs e)
        {
            using (Form popup = new Form())
            {
                popup.Width = 400;
                popup.Height = 350;
                popup.Text = "Criar Menu";

                // Criar ComboBox para selecionar pratos
                ComboBox comboBox_Pratos = new ComboBox()
                {
                    Left = 20,
                    Top = 20,
                    Width = 200,
                    DropDownStyle = ComboBoxStyle.DropDownList
                };
                popup.Controls.Add(comboBox_Pratos);

                // Carregar pratos disponíveis
                LoadPratos(comboBox_Pratos);

                // Criar Panel para adicionar CheckBoxes de Extras
                Panel panel_Extras = new Panel()
                {
                    Left = 20,
                    Top = 60,
                    Width = 300,
                    Height = 200
                };
                popup.Controls.Add(panel_Extras);

                // Carregar extras disponíveis
                LoadExtras(panel_Extras);

                // Botão OK
                Button btnOK = new Button()
                {
                    Text = "OK",
                    Left = 150,
                    Width = 80,
                    Top = 280
                };
                btnOK.Click += (s, ev) =>
                {
                    // Inserir apenas prato e extras na base de dados
                    string pratoSelecionado = comboBox_Pratos.SelectedItem?.ToString();
                    if (string.IsNullOrEmpty(pratoSelecionado))
                    {
                        MessageBox.Show("Por favor, selecione um prato.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    List<string> extrasSelecionados = new List<string>();
                    foreach (CheckBox checkBox in panel_Extras.Controls)
                    {
                        if (checkBox.Checked)
                        {
                            extrasSelecionados.Add(checkBox.Text);
                        }
                    }

                    // Montar string de extras separados por vírgula
                    string extrasConcatenados = string.Join(",", extrasSelecionados);

                    // Inserir na base de dados
                    string query = "INSERT INTO Menus (Prato, Extra) VALUES (@Prato, @Extra)";
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@Prato", pratoSelecionado);
                            command.Parameters.AddWithValue("@Extra", extrasConcatenados);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Menu criado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadMenus(); // Atualizar a ListBox de Menus após inserção
                            }
                            else
                            {
                                MessageBox.Show("Falha ao criar o menu.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erro ao criar menu: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    popup.DialogResult = DialogResult.OK;
                    popup.Close();
                };
                popup.Controls.Add(btnOK);

                // Botão Cancelar
                Button btnCancel = new Button()
                {
                    Text = "Cancelar",
                    Left = 250,
                    Width = 80,
                    Top = 280
                };
                btnCancel.Click += (s, ev) =>
                {
                    popup.DialogResult = DialogResult.Cancel;
                    popup.Close();
                };
                popup.Controls.Add(btnCancel);

                // Mostrar o popup como um diálogo modal
                if (popup.ShowDialog() == DialogResult.OK)
                {
                    // Aqui você pode processar o resultado se necessário
                }
            }
        }

        private void LoadPratos(ComboBox comboBox_Pratos)
        {
            comboBox_Pratos.Items.Clear();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao FROM Pratos";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricaoPrato = reader["descricao"].ToString();
                        comboBox_Pratos.Items.Add(descricaoPrato);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar pratos: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadExtras(Panel panel_Extras)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao FROM Extras";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    int top = 20;
                    while (reader.Read())
                    {
                        string DescricaoExtra = reader["descricao"].ToString();
                        CheckBox checkBox = new CheckBox()
                        {
                            Text = DescricaoExtra,
                            Left = 20,
                            Top = top,
                            Width = 200
                        };
                        panel_Extras.Controls.Add(checkBox);
                        top += 30;
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar extras: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadMenus()
        {
            listBox_Menus.Items.Clear();

            // Conectar ao banco de dados e carregar menus
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Prato, Extra FROM Menus";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string Prato = reader["Prato"].ToString();
                        string Extra = reader["Extra"].ToString(); // Ler como string

                        // Formatar como uma única linha
                        string menuInfo = $"{Prato} - Extras: {Extra}";
                        listBox_Menus.Items.Add(menuInfo);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar menus: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private List<string> GetSelecoes(ComboBox comboBox_Pratos, Panel panel_Extras)
        {
            List<string> selecoes = new List<string>();

            string pratoSelecionado = comboBox_Pratos.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(pratoSelecionado))
            {
                selecoes.Add($"Prato: {pratoSelecionado}");
            }

            foreach (CheckBox checkBox in panel_Extras.Controls)
            {
                if (checkBox.Checked)
                {
                    selecoes.Add($"Extra: {checkBox.Text}");
                }
            }

            return selecoes;
        }

        private void button_Editar_Menu_Click(object sender, EventArgs e)
        {
            // Verificar se um menu está selecionado na listBox_Menus
            if (listBox_Menus.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione um menu para editar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Obter a string do menu selecionado
            string menuSelecionado = listBox_Menus.SelectedItem.ToString();

            // Extrair prato e extras do menu selecionado (você pode usar regex ou split para isso)
            string prato = ""; // extrair o prato do menuSelecionado
            string extras = ""; // extrair os extras do menuSelecionado

            // Abrir o formulário pop-up para editar o menu selecionado
            using (Form popup = new Form())
            {
                popup.Width = 400;
                popup.Height = 350;
                popup.Text = "Atualizar Menu";

                // Criar ComboBox para selecionar pratos
                ComboBox comboBox_Pratos = new ComboBox()
                {
                    Left = 20,
                    Top = 20,
                    Width = 200,
                    DropDownStyle = ComboBoxStyle.DropDownList
                };
                popup.Controls.Add(comboBox_Pratos);

                // Carregar pratos disponíveis
                LoadPratos(comboBox_Pratos);

                // Selecionar o prato correto no ComboBox
                comboBox_Pratos.SelectedItem = prato;

                // Criar Panel para adicionar CheckBoxes de Extras
                Panel panel_Extras = new Panel()
                {
                    Left = 20,
                    Top = 60,
                    Width = 300,
                    Height = 200
                };
                popup.Controls.Add(panel_Extras);

                // Carregar extras disponíveis
                LoadExtras(panel_Extras);

                // Marcar as CheckBoxes corretas com base nos extras do menu selecionado
                string[] extrasSelecionados = extras.Split(',');
                foreach (CheckBox checkBox in panel_Extras.Controls)
                {
                    checkBox.Checked = extrasSelecionados.Contains(checkBox.Text);
                }

                // Criar TextBox para inserir o preço
                TextBox textBox_Preco = new TextBox()
                {
                    Left = 20,
                    Top = 270,
                    Width = 100,
                    Text = "", // preencher com o preço do menu selecionado
                };
                popup.Controls.Add(textBox_Preco);

                // Botão OK
                Button btnOK = new Button()
                {
                    Text = "OK",
                    Left = 150,
                    Width = 80,
                    Top = 280
                };
                btnOK.Click += (s, ev) =>
                {
                    // Inserir apenas prato, extras e preço na base de dados
                    string novoPratoSelecionado = comboBox_Pratos.SelectedItem?.ToString();
                    if (string.IsNullOrEmpty(novoPratoSelecionado))
                    {
                        MessageBox.Show("Por favor, selecione um prato.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    List<string> novosExtrasSelecionados = new List<string>();
                    foreach (CheckBox checkBox in panel_Extras.Controls)
                    {
                        if (checkBox.Checked)
                        {
                            novosExtrasSelecionados.Add(checkBox.Text);
                        }
                    }

                    // Montar string de extras separados por vírgula
                    string novosExtrasConcatenados = string.Join(",", novosExtrasSelecionados);

                    // Obter o novo preço
                    decimal novoPreco;
                    if (!decimal.TryParse(textBox_Preco.Text, out novoPreco))
                    {
                        MessageBox.Show("Por favor, insira um preço válido.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Atualizar na base de dados
                    string query = "UPDATE Menus SET Prato = @Prato, Extra = @Extra, Preco = @Preco WHERE Id_Menu = @Id_Menu";
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            SqlCommand command = new SqlCommand(query, connection);
                            command.Parameters.AddWithValue("@Prato", novoPratoSelecionado);
                            command.Parameters.AddWithValue("@Extra", novosExtrasConcatenados);
                            command.Parameters.AddWithValue("@Preco", novoPreco);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Menu atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadMenus(); // Atualizar a ListBox de Menus após atualização
                            }
                            else
                            {
                                MessageBox.Show("Falha ao atualizar o menu.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erro ao atualizar menu: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    popup.DialogResult = DialogResult.OK;
                    popup.Close();
                };
                popup.Controls.Add(btnOK);

                // Botão Cancelar
                Button btnCancel = new Button()
                {
                    Text = "Cancelar",
                    Left = 250,
                    Width = 80,
                    Top = 280
                };
                btnCancel.Click += (s, ev) =>
                {
                    popup.DialogResult = DialogResult.Cancel;
                    popup.Close();
                };
                popup.Controls.Add(btnCancel);
            }
        }

        private void button_Apagar_Menu_Click(object sender, EventArgs e)
        {
            // Verificar se um item está selecionado na listBox_Menus
            if (listBox_Menus.SelectedIndex != -1)
            {
                // Extrair prato e extras do menu selecionado
                string selectedMenuInfo = listBox_Menus.SelectedItem.ToString();
                string[] parts = selectedMenuInfo.Split(new string[] { " - Extras: " }, StringSplitOptions.None);
                if (parts.Length == 2)
                {
                    string prato = parts[0];
                    string extras = parts[1];

                    // Remover o item da listBox_Menus
                    listBox_Menus.Items.RemoveAt(listBox_Menus.SelectedIndex);

                    // Apagar da base de dados
                    DeleteMenuFromDatabase(prato, extras);
                }
                else
                {
                    MessageBox.Show("Formato de menu inválido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Por favor, selecione um menu para apagar.", "Seleção Necessária", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DeleteMenuFromDatabase(string prato, string extras)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Menus WHERE Prato = @Prato AND Extra = @Extra";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Prato", prato);
                    command.Parameters.AddWithValue("@Extra", extras);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Menu apagado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Falha ao apagar o menu.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao apagar menu: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
