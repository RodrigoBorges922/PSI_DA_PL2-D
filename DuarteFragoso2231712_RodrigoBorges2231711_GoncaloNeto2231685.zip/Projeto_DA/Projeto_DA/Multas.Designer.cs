﻿namespace Projeto_DA
{
    partial class Multas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Apagar_Multa = new System.Windows.Forms.Button();
            this.button_Editar_Multa = new System.Windows.Forms.Button();
            this.button_Adicionar_Multa = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.listBox_Multas = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-22, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1061, 36);
            this.panel1.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(500, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "Multas";
            // 
            // button_Apagar_Multa
            // 
            this.button_Apagar_Multa.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Multa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Multa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Multa.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Multa.Location = new System.Drawing.Point(836, 358);
            this.button_Apagar_Multa.Name = "button_Apagar_Multa";
            this.button_Apagar_Multa.Size = new System.Drawing.Size(89, 67);
            this.button_Apagar_Multa.TabIndex = 56;
            this.button_Apagar_Multa.Text = "Apagar";
            this.button_Apagar_Multa.UseVisualStyleBackColor = false;
            this.button_Apagar_Multa.Click += new System.EventHandler(this.button_Apagar_Multa_Click);
            // 
            // button_Editar_Multa
            // 
            this.button_Editar_Multa.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Multa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Multa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Multa.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Multa.Location = new System.Drawing.Point(836, 283);
            this.button_Editar_Multa.Name = "button_Editar_Multa";
            this.button_Editar_Multa.Size = new System.Drawing.Size(89, 69);
            this.button_Editar_Multa.TabIndex = 55;
            this.button_Editar_Multa.Text = "Editar";
            this.button_Editar_Multa.UseVisualStyleBackColor = false;
            this.button_Editar_Multa.Click += new System.EventHandler(this.button_Editar_Multa_Click);
            // 
            // button_Adicionar_Multa
            // 
            this.button_Adicionar_Multa.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Multa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Multa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Multa.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Multa.Location = new System.Drawing.Point(836, 208);
            this.button_Adicionar_Multa.Name = "button_Adicionar_Multa";
            this.button_Adicionar_Multa.Size = new System.Drawing.Size(89, 69);
            this.button_Adicionar_Multa.TabIndex = 54;
            this.button_Adicionar_Multa.Text = "Adicionar";
            this.button_Adicionar_Multa.UseVisualStyleBackColor = false;
            this.button_Adicionar_Multa.Click += new System.EventHandler(this.button_Adicionar_Multa_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Projeto_DA.Properties.Resources.homepage1;
            this.pictureBox2.Location = new System.Drawing.Point(931, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 58;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // listBox_Multas
            // 
            this.listBox_Multas.BackColor = System.Drawing.Color.Red;
            this.listBox_Multas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listBox_Multas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Multas.ForeColor = System.Drawing.Color.White;
            this.listBox_Multas.FormattingEnabled = true;
            this.listBox_Multas.ItemHeight = 20;
            this.listBox_Multas.Location = new System.Drawing.Point(43, 208);
            this.listBox_Multas.Name = "listBox_Multas";
            this.listBox_Multas.Size = new System.Drawing.Size(405, 304);
            this.listBox_Multas.TabIndex = 59;
            // 
            // Multas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.listBox_Multas);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_Apagar_Multa);
            this.Controls.Add(this.button_Editar_Multa);
            this.Controls.Add(this.button_Adicionar_Multa);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Multas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Multas";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_Apagar_Multa;
        private System.Windows.Forms.Button button_Editar_Multa;
        private System.Windows.Forms.Button button_Adicionar_Multa;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListBox listBox_Multas;
    }
}