﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DA
{
    public partial class Funcionarios : Form
    {

        string connectionString = String.Format(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\rodri\Desktop\Projeto_DA\Projeto_DA\Database1.mdf;Integrated Security = True");
    
        public Funcionarios()
        {
            InitializeComponent();
            LoadDataIntoListBox_Funcionarios();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void LoadDataIntoListBox_Funcionarios()
        {
            listBox_Funcionarios.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT nome, id, nif FROM Funcionarios";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        string id = reader["id"].ToString();
                        string nif = reader["nif"].ToString();
                        listBox_Funcionarios.Items.Add($"{nome} - {id} - {nif}");
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_Adicionar_Funcionario_Click(object sender, EventArgs e)
        {
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 250;
            popup.Text = "Adicionar Funcionário";

            Label labelNome = new Label() { Left = 20, Top = 20, Text = "Nome" };
            TextBox textNome = new TextBox() { Left = 120, Top = 20, Width = 150 };

            Label labelId = new Label() { Left = 20, Top = 60, Text = "ID" };
            TextBox textId = new TextBox() { Left = 120, Top = 60, Width = 150 };

            Label labelNIF = new Label() { Left = 20, Top = 100, Text = "NIF" };
            TextBox textNIF = new TextBox() { Left = 120, Top = 100, Width = 150 };

            Button btnOk = new Button() { Text = "OK", Left = 120, Width = 80, Top = 140 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(textNome.Text) ||
                    string.IsNullOrWhiteSpace(textId.Text) ||
                    string.IsNullOrWhiteSpace(textNIF.Text))
                {
                    MessageBox.Show("Por favor, preencha todos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validar tamanho do NIF
                if (textNIF.Text.Length != 9)
                {
                    MessageBox.Show("O NIF deve conter exatamente 9 dígitos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Inserir dados na base de dados
                string insertQuery = "INSERT INTO Funcionarios (nome, id, nif) VALUES (@Nome, @Id, @NIF)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(insertQuery, connection);
                    command.Parameters.AddWithValue("@Nome", textNome.Text);
                    command.Parameters.AddWithValue("@Id", textId.Text);
                    command.Parameters.AddWithValue("@NIF", textNIF.Text);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Funcionário adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Limpar e recarregar a ListBox com os funcionários atualizados
                            listBox_Funcionarios.Items.Clear();
                            LoadDataIntoListBox_Funcionarios(); // Método para carregar os dados na ListBox
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível adicionar o funcionário.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao inserir o funcionário: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(labelNome);
            popup.Controls.Add(textNome);
            popup.Controls.Add(labelId);
            popup.Controls.Add(textId);
            popup.Controls.Add(labelNIF);
            popup.Controls.Add(textNIF);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Editar_Funcionario_Click(object sender, EventArgs e)
        {
            // Verificar se um funcionário está selecionado na ListBox
            if (listBox_Funcionarios.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione um funcionário para editar.", "Seleção Necessária", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obter o funcionário selecionado na ListBox
            string funcionarioSelecionado = listBox_Funcionarios.SelectedItem.ToString();

            // Extrair o nome do funcionário da string exibida na ListBox (considerando um formato "Nome - ID - NIF")
            string nomeFuncionario = funcionarioSelecionado.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries)[0];

            // Consultar o banco de dados para obter os detalhes do funcionário selecionado
            string query = "SELECT * FROM Funcionarios WHERE nome = @Nome";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nome", nomeFuncionario);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Obter os dados do funcionário
                        string idFuncionario = reader["id"].ToString();
                        string nifFuncionario = reader["nif"].ToString();

                        // Fechar o SqlDataReader após obter os dados necessários
                        reader.Close();

                        // Criar o formulário de edição
                        Form popup = new Form();
                        popup.Width = 300;
                        popup.Height = 250;
                        popup.Text = "Editar Funcionário";

                        Label labelNome = new Label() { Left = 20, Top = 20, Text = "Nome" };
                        TextBox textNome = new TextBox() { Left = 120, Top = 20, Width = 150, Text = nomeFuncionario };

                        Label labelId = new Label() { Left = 20, Top = 60, Text = "ID" };
                        TextBox textId = new TextBox() { Left = 120, Top = 60, Width = 150, Text = idFuncionario };

                        Label labelNIF = new Label() { Left = 20, Top = 100, Text = "NIF" };
                        TextBox textNIF = new TextBox() { Left = 120, Top = 100, Width = 150, Text = nifFuncionario };

                        Button btnOk = new Button() { Text = "OK", Left = 120, Width = 80, Top = 140 };
                        btnOk.Click += (s, ev) =>
                        {
                            // Validar entrada
                            if (string.IsNullOrWhiteSpace(textNome.Text) ||
                                string.IsNullOrWhiteSpace(textId.Text) ||
                                string.IsNullOrWhiteSpace(textNIF.Text))
                            {
                                MessageBox.Show("Por favor, preencha todos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Validar tamanho do NIF
                            if (textNIF.Text.Length != 9)
                            {
                                MessageBox.Show("O NIF deve conter exatamente 9 dígitos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Atualizar os dados do funcionário no banco de dados
                            string updateQuery = "UPDATE Funcionarios SET nome = @Nome, id = @Id, nif = @NIF WHERE nome = @NomeSelecionado";
                            SqlCommand updateCommand = new SqlCommand(updateQuery, connection);
                            updateCommand.Parameters.AddWithValue("@Nome", textNome.Text);
                            updateCommand.Parameters.AddWithValue("@Id", textId.Text);
                            updateCommand.Parameters.AddWithValue("@NIF", textNIF.Text);
                            updateCommand.Parameters.AddWithValue("@NomeSelecionado", nomeFuncionario);

                            try
                            {
                                int rowsAffected = updateCommand.ExecuteNonQuery();
                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Funcionário atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    // Limpar e recarregar a ListBox com os funcionários atualizados
                                    listBox_Funcionarios.Items.Clear();
                                    LoadDataIntoListBox_Funcionarios(); // Método para carregar os dados na ListBox
                                }
                                else
                                {
                                    MessageBox.Show("Não foi possível atualizar o funcionário.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ocorreu um erro ao atualizar o funcionário: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            popup.DialogResult = DialogResult.OK;
                            popup.Close();
                        };

                        popup.Controls.Add(labelNome);
                        popup.Controls.Add(textNome);
                        popup.Controls.Add(labelId);
                        popup.Controls.Add(textId);
                        popup.Controls.Add(labelNIF);
                        popup.Controls.Add(textNIF);
                        popup.Controls.Add(btnOk);
                        popup.AcceptButton = btnOk;

                        popup.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Funcionário não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocorreu um erro ao buscar os dados do funcionário: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button_Apagar_Funcionario_Click(object sender, EventArgs e)
        {
            // Verificar se um funcionário está selecionado na ListBox
            if (listBox_Funcionarios.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione um funcionário para apagar.", "Seleção Necessária", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obter o funcionário selecionado na ListBox
            string funcionarioSelecionado = listBox_Funcionarios.SelectedItem.ToString();

            // Extrair o nome do funcionário da string exibida na ListBox (considerando um formato "Nome - ID - NIF")
            string nomeFuncionario = funcionarioSelecionado.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries)[0];

            // Confirmar se o usuário deseja realmente apagar o funcionário
            DialogResult confirmacao = MessageBox.Show($"Tem certeza que deseja apagar o funcionário '{nomeFuncionario}'?", "Confirmação de Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmacao == DialogResult.Yes)
            {
                // Executar a exclusão no banco de dados
                string deleteQuery = "DELETE FROM Funcionarios WHERE nome = @Nome";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(deleteQuery, connection);
                    command.Parameters.AddWithValue("@Nome", nomeFuncionario);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Funcionário apagado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Limpar e recarregar a ListBox com os funcionários atualizados
                            listBox_Funcionarios.Items.Clear();
                            LoadDataIntoListBox_Funcionarios(); // Método para carregar os dados na ListBox
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível apagar o funcionário.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao apagar o funcionário: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
