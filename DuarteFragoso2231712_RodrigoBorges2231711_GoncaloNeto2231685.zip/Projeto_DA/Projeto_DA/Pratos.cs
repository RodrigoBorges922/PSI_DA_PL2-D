﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DA
{
    public partial class Pratos : Form
    {
        string connectionString = String.Format(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\rodri\Desktop\Projeto_DA\Projeto_DA\Database1.mdf;Integrated Security = True");
        public Pratos()
        {
            InitializeComponent();
            LoadDataIntoListBox_Prato_Carne();
            LoadDataIntoListBox_Prato_Peixe();
            LoadDataIntoListBox_Prato_Vegan();
        }

        private void LoadDataIntoListBox_Prato_Carne()
        {

            listBox_Prato_Carne.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao, Tipo FROM Pratos WHERE Tipo LIKE 'carne'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        string tipo = (string)reader["Tipo"];
                        listBox_Prato_Carne.Items.Add($"{descricao} - {tipo:C}");
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadDataIntoListBox_Prato_Peixe()
        {

            listBox_Prato_Peixe.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao, Tipo FROM Pratos WHERE Tipo LIKE 'peixe'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        string tipo = (string)reader["Tipo"];
                        listBox_Prato_Peixe.Items.Add($"{descricao} - {tipo:C}");
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadDataIntoListBox_Prato_Vegan()
        {

            listBox_Prato_Vegan.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao, Tipo FROM Pratos WHERE Tipo LIKE 'vegan'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        string tipo = (string)reader["Tipo"];
                        listBox_Prato_Vegan.Items.Add($"{descricao} - {tipo:C}");
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Adicionar_Carne_Click(object sender, EventArgs e)
        {
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Nome e Tipo";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150 };

            Label lblTipo = new Label() { Left = 10, Top = 60, Text = "Tipo" };
            TextBox txtTipo = new TextBox() { Left = 110, Top = 60, Width = 150 };

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
    {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtTipo.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "INSERT INTO Pratos (Descricao, Tipo) VALUES (@Name, @Tipo)";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Tipo", txtTipo.Text);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                        MessageBox.Show("Item adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Prato_Carne(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível adicionar o item.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao inserir o item: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblTipo);
            popup.Controls.Add(txtTipo);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
            }

        private void button_Adicionar_Peixe_Click(object sender, EventArgs e)
        {
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Nome e Tipo";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150 };

            Label lblTipo = new Label() { Left = 10, Top = 60, Text = "Tipo" };
            TextBox txtTipo = new TextBox() { Left = 110, Top = 60, Width = 150 };

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtTipo.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "INSERT INTO Pratos (Descricao, Tipo) VALUES (@Name, @Tipo)";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Tipo", txtTipo.Text);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Item adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Prato_Peixe(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível adicionar o item.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao inserir o item: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblTipo);
            popup.Controls.Add(txtTipo);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Adicionar_Vegan_Click(object sender, EventArgs e)
        {
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Nome e Tipo";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150 };

            Label lblTipo = new Label() { Left = 10, Top = 60, Text = "Tipo" };
            TextBox txtTipo = new TextBox() { Left = 110, Top = 60, Width = 150 };

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtTipo.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "INSERT INTO Pratos (Descricao, Tipo) VALUES (@Name, @Tipo)";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Tipo", txtTipo.Text);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Item adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Prato_Vegan(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível adicionar o item.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao inserir o item: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblTipo);
            popup.Controls.Add(txtTipo);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Editar_Carne_Click(object sender, EventArgs e)
        {
            if (listBox_Prato_Carne.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um prato de carne para editar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Extrair a descrição e o tipo do item selecionado
            string selectedItem = listBox_Prato_Carne.SelectedItem.ToString();
            string descricao = selectedItem.Substring(0, selectedItem.IndexOf(" - "));
            string tipo = selectedItem.Substring(selectedItem.IndexOf("- ") + 2);

            // Abrir um formulário de edição com os dados do item selecionado
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Editar Nome e Tipo";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150, Text = descricao };

            Label lblTipo = new Label() { Left = 10, Top = 60, Text = "Tipo" };
            TextBox txtTipo = new TextBox() { Left = 110, Top = 60, Width = 150, Text = tipo }; // Preenche o campo com o tipo obtido

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtTipo.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL para atualizar o item
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "UPDATE Pratos SET Descricao = @Name, Tipo = @Tipo WHERE Descricao = @OldName AND Tipo LIKE 'carne'";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Tipo", txtTipo.Text);
                        command.Parameters.AddWithValue("@OldName", descricao);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Prato editado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Prato_Carne(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível editar o prato.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao editar o prato: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblTipo);
            popup.Controls.Add(txtTipo);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Apagar_Carne_Click(object sender, EventArgs e)
        {
            if (listBox_Prato_Carne.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um prato para apagar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedItem = listBox_Prato_Carne.SelectedItem.ToString();
            // Extrair a descrição do item selecionado
            string descricao = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None)[0];

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Pratos WHERE Descricao = @Descricao AND Tipo LIKE 'carne'";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Descricao", descricao);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Prato apagado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDataIntoListBox_Prato_Carne(); // Atualizar a lista de itens
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível apagar o prato!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocorreu um erro ao apagar o prato: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_Editar_Peixe_Click(object sender, EventArgs e)
        {
            if (listBox_Prato_Peixe.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um prato de peixe para editar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Extrair a descrição e o tipo do item selecionado
            string selectedItem = listBox_Prato_Peixe.SelectedItem.ToString();
            string descricao = selectedItem.Substring(0, selectedItem.IndexOf(" - "));
            string tipo = selectedItem.Substring(selectedItem.IndexOf("- ") + 2); // Obtém o tipo a partir de "- "

            // Abrir um formulário de edição com os dados do item selecionado
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Editar Nome e Tipo";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150, Text = descricao };

            Label lblTipo = new Label() { Left = 10, Top = 60, Text = "Tipo" };
            TextBox txtTipo = new TextBox() { Left = 110, Top = 60, Width = 150, Text = tipo }; // Preenche o campo com o tipo obtido

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtTipo.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL para atualizar o item
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "UPDATE Pratos SET Descricao = @Name, Tipo = @Tipo WHERE Descricao = @OldName AND Tipo LIKE 'peixe'";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Tipo", txtTipo.Text);
                        command.Parameters.AddWithValue("@OldName", descricao);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Prato editado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Prato_Peixe(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível editar o prato.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao editar o prato: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblTipo);
            popup.Controls.Add(txtTipo);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Editar_Vegan_Click(object sender, EventArgs e)
        {
            if (listBox_Prato_Vegan.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um prato vegan para editar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Extrair a descrição e o tipo do item selecionado
            string selectedItem = listBox_Prato_Vegan.SelectedItem.ToString();
            string descricao = selectedItem.Substring(0, selectedItem.IndexOf(" - "));
            string tipo = selectedItem.Substring(selectedItem.IndexOf("- ") + 2);

            // Abrir um formulário de edição com os dados do item selecionado
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Editar Nome e Tipo";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150, Text = descricao };

            Label lblTipo = new Label() { Left = 10, Top = 60, Text = "Tipo" };
            TextBox txtTipo = new TextBox() { Left = 110, Top = 60, Width = 150, Text = tipo };

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtTipo.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL para atualizar o item
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "UPDATE Pratos SET Descricao = @Name, Tipo = @Tipo WHERE Descricao = @OldName AND Tipo LIKE 'vegan'";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Tipo", txtTipo.Text);
                        command.Parameters.AddWithValue("@OldName", descricao);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Prato editado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Prato_Vegan(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível editar o prato.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao editar o prato: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblTipo);
            popup.Controls.Add(txtTipo);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Apagar_Peixe_Click(object sender, EventArgs e)
        {
            if (listBox_Prato_Peixe.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um prato para apagar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedItem = listBox_Prato_Peixe.SelectedItem.ToString();
            // Extrair a descrição do item selecionado
            string descricao = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None)[0];

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Pratos WHERE Descricao = @Descricao AND Tipo LIKE 'peixe'";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Descricao", descricao);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Prato apagado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDataIntoListBox_Prato_Peixe(); // Atualizar a lista de itens
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível apagar o prato!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocorreu um erro ao apagar o prato: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_Apagar_Vegan_Click(object sender, EventArgs e)
        {
            if (listBox_Prato_Vegan.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um prato para apagar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedItem = listBox_Prato_Vegan.SelectedItem.ToString();
            // Extrair a descrição do item selecionado
            string descricao = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None)[0];

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Pratos WHERE Descricao = @Descricao AND Tipo LIKE 'vegan'";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Descricao", descricao);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Prato apagado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDataIntoListBox_Prato_Vegan(); // Atualizar a lista de itens
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível apagar o prato!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocorreu um erro ao apagar o prato: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
