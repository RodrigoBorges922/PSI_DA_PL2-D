﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DA
{
    public partial class Reservas : Form
    {

        string connectionString = String.Format(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\rodri\Desktop\Projeto_DA\Projeto_DA\Database1.mdf;Integrated Security=True");
        public Reservas()
        {
            InitializeComponent();
            LoadDataIntoCheckedListBox_Extras_Reserva();
            LoadDataIntoListBox_Menu_Carne();
            LoadDataIntoListBox_Menu_Peixe();
            LoadDataIntoListBox_Menu_Vegan();


        }

        private void LoadDataIntoCheckedListBox_Extras_Reserva()
        {
            checkedListBox_Extras_Reserva.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao, Preco FROM Extras";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        decimal preco = reader.GetDecimal(reader.GetOrdinal("Preco"));
                        string item = $"{descricao} - {preco:C}"; // Exemplo de formatação
                        checkedListBox_Extras_Reserva.Items.Add(item);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void LoadDataIntoListBox_Menu_Carne()
        {
            listBox_Menu_Carne.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao FROM Pratos WHERE Tipo = 'carne'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        listBox_Menu_Carne.Items.Add(descricao);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadDataIntoListBox_Menu_Peixe()
        {
            listBox_Menu_Peixe.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao FROM Pratos WHERE Tipo = 'peixe'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        listBox_Menu_Peixe.Items.Add(descricao);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadDataIntoListBox_Menu_Vegan()
        {
            listBox_Menu_Vegan.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao FROM Pratos WHERE Tipo = 'vegan'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        listBox_Menu_Vegan.Items.Add(descricao);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
