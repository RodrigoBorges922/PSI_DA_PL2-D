﻿namespace Projeto_DA
{
    partial class Pratos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button_Adicionar_Carne = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Adicionar_Vegan = new System.Windows.Forms.Button();
            this.button_Adicionar_Peixe = new System.Windows.Forms.Button();
            this.button_Editar_Carne = new System.Windows.Forms.Button();
            this.button_Editar_Vegan = new System.Windows.Forms.Button();
            this.button_Editar_Peixe = new System.Windows.Forms.Button();
            this.button_Apagar_Carne = new System.Windows.Forms.Button();
            this.button_Apagar_Vegan = new System.Windows.Forms.Button();
            this.button_Apagar_Peixe = new System.Windows.Forms.Button();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listBox_Prato_Carne = new System.Windows.Forms.ListBox();
            this.listBox_Prato_Peixe = new System.Windows.Forms.ListBox();
            this.listBox_Prato_Vegan = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-22, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1061, 36);
            this.panel1.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(500, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 24);
            this.label7.TabIndex = 41;
            this.label7.Text = "Pratos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 20);
            this.label1.TabIndex = 35;
            this.label1.Text = "Pratos de Carne";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 330);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 20);
            this.label3.TabIndex = 37;
            this.label3.Text = "Pratos de Peixe";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 482);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 20);
            this.label5.TabIndex = 39;
            this.label5.Text = "Pratos Vegans";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // button_Adicionar_Carne
            // 
            this.button_Adicionar_Carne.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Carne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Carne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Carne.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Carne.Location = new System.Drawing.Point(742, 175);
            this.button_Adicionar_Carne.Name = "button_Adicionar_Carne";
            this.button_Adicionar_Carne.Size = new System.Drawing.Size(75, 42);
            this.button_Adicionar_Carne.TabIndex = 41;
            this.button_Adicionar_Carne.Text = "Adicionar";
            this.button_Adicionar_Carne.UseVisualStyleBackColor = false;
            this.button_Adicionar_Carne.Click += new System.EventHandler(this.button_Adicionar_Carne_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(-25, 304);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1061, 23);
            this.panel2.TabIndex = 42;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Red;
            this.panel3.Location = new System.Drawing.Point(1, 453);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1061, 23);
            this.panel3.TabIndex = 43;
            // 
            // button_Adicionar_Vegan
            // 
            this.button_Adicionar_Vegan.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Vegan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Vegan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Vegan.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Vegan.Location = new System.Drawing.Point(742, 505);
            this.button_Adicionar_Vegan.Name = "button_Adicionar_Vegan";
            this.button_Adicionar_Vegan.Size = new System.Drawing.Size(75, 42);
            this.button_Adicionar_Vegan.TabIndex = 44;
            this.button_Adicionar_Vegan.Text = "Adicionar";
            this.button_Adicionar_Vegan.UseVisualStyleBackColor = false;
            this.button_Adicionar_Vegan.Click += new System.EventHandler(this.button_Adicionar_Vegan_Click);
            // 
            // button_Adicionar_Peixe
            // 
            this.button_Adicionar_Peixe.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Peixe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Peixe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Peixe.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Peixe.Location = new System.Drawing.Point(742, 353);
            this.button_Adicionar_Peixe.Name = "button_Adicionar_Peixe";
            this.button_Adicionar_Peixe.Size = new System.Drawing.Size(75, 42);
            this.button_Adicionar_Peixe.TabIndex = 45;
            this.button_Adicionar_Peixe.Text = "Adicionar";
            this.button_Adicionar_Peixe.UseVisualStyleBackColor = false;
            this.button_Adicionar_Peixe.Click += new System.EventHandler(this.button_Adicionar_Peixe_Click);
            // 
            // button_Editar_Carne
            // 
            this.button_Editar_Carne.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Carne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Carne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Carne.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Carne.Location = new System.Drawing.Point(823, 175);
            this.button_Editar_Carne.Name = "button_Editar_Carne";
            this.button_Editar_Carne.Size = new System.Drawing.Size(75, 42);
            this.button_Editar_Carne.TabIndex = 46;
            this.button_Editar_Carne.Text = "Editar";
            this.button_Editar_Carne.UseVisualStyleBackColor = false;
            this.button_Editar_Carne.Click += new System.EventHandler(this.button_Editar_Carne_Click);
            // 
            // button_Editar_Vegan
            // 
            this.button_Editar_Vegan.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Vegan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Vegan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Vegan.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Vegan.Location = new System.Drawing.Point(823, 505);
            this.button_Editar_Vegan.Name = "button_Editar_Vegan";
            this.button_Editar_Vegan.Size = new System.Drawing.Size(75, 42);
            this.button_Editar_Vegan.TabIndex = 47;
            this.button_Editar_Vegan.Text = "Editar";
            this.button_Editar_Vegan.UseVisualStyleBackColor = false;
            this.button_Editar_Vegan.Click += new System.EventHandler(this.button_Editar_Vegan_Click);
            // 
            // button_Editar_Peixe
            // 
            this.button_Editar_Peixe.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Peixe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Peixe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Peixe.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Peixe.Location = new System.Drawing.Point(823, 353);
            this.button_Editar_Peixe.Name = "button_Editar_Peixe";
            this.button_Editar_Peixe.Size = new System.Drawing.Size(75, 42);
            this.button_Editar_Peixe.TabIndex = 48;
            this.button_Editar_Peixe.Text = "Editar";
            this.button_Editar_Peixe.UseVisualStyleBackColor = false;
            this.button_Editar_Peixe.Click += new System.EventHandler(this.button_Editar_Peixe_Click);
            // 
            // button_Apagar_Carne
            // 
            this.button_Apagar_Carne.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Carne.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Carne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Carne.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Carne.Location = new System.Drawing.Point(904, 175);
            this.button_Apagar_Carne.Name = "button_Apagar_Carne";
            this.button_Apagar_Carne.Size = new System.Drawing.Size(75, 42);
            this.button_Apagar_Carne.TabIndex = 49;
            this.button_Apagar_Carne.Text = "Apagar";
            this.button_Apagar_Carne.UseVisualStyleBackColor = false;
            this.button_Apagar_Carne.Click += new System.EventHandler(this.button_Apagar_Carne_Click);
            // 
            // button_Apagar_Vegan
            // 
            this.button_Apagar_Vegan.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Vegan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Vegan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Vegan.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Vegan.Location = new System.Drawing.Point(904, 505);
            this.button_Apagar_Vegan.Name = "button_Apagar_Vegan";
            this.button_Apagar_Vegan.Size = new System.Drawing.Size(75, 42);
            this.button_Apagar_Vegan.TabIndex = 50;
            this.button_Apagar_Vegan.Text = "Apagar";
            this.button_Apagar_Vegan.UseVisualStyleBackColor = false;
            this.button_Apagar_Vegan.Click += new System.EventHandler(this.button_Apagar_Vegan_Click);
            // 
            // button_Apagar_Peixe
            // 
            this.button_Apagar_Peixe.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Peixe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Peixe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Peixe.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Peixe.Location = new System.Drawing.Point(904, 353);
            this.button_Apagar_Peixe.Name = "button_Apagar_Peixe";
            this.button_Apagar_Peixe.Size = new System.Drawing.Size(75, 42);
            this.button_Apagar_Peixe.TabIndex = 51;
            this.button_Apagar_Peixe.Text = "Apagar";
            this.button_Apagar_Peixe.UseVisualStyleBackColor = false;
            this.button_Apagar_Peixe.Click += new System.EventHandler(this.button_Apagar_Peixe_Click);
            // 
            // imageList2
            // 
            this.imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList2.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Projeto_DA.Properties.Resources.homepage1;
            this.pictureBox2.Location = new System.Drawing.Point(931, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 52;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // listBox_Prato_Carne
            // 
            this.listBox_Prato_Carne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Prato_Carne.FormattingEnabled = true;
            this.listBox_Prato_Carne.ItemHeight = 16;
            this.listBox_Prato_Carne.Location = new System.Drawing.Point(38, 175);
            this.listBox_Prato_Carne.Name = "listBox_Prato_Carne";
            this.listBox_Prato_Carne.Size = new System.Drawing.Size(224, 84);
            this.listBox_Prato_Carne.TabIndex = 53;
            // 
            // listBox_Prato_Peixe
            // 
            this.listBox_Prato_Peixe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Prato_Peixe.FormattingEnabled = true;
            this.listBox_Prato_Peixe.ItemHeight = 16;
            this.listBox_Prato_Peixe.Location = new System.Drawing.Point(38, 353);
            this.listBox_Prato_Peixe.Name = "listBox_Prato_Peixe";
            this.listBox_Prato_Peixe.Size = new System.Drawing.Size(224, 84);
            this.listBox_Prato_Peixe.TabIndex = 54;
            // 
            // listBox_Prato_Vegan
            // 
            this.listBox_Prato_Vegan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Prato_Vegan.FormattingEnabled = true;
            this.listBox_Prato_Vegan.ItemHeight = 16;
            this.listBox_Prato_Vegan.Location = new System.Drawing.Point(38, 505);
            this.listBox_Prato_Vegan.Name = "listBox_Prato_Vegan";
            this.listBox_Prato_Vegan.Size = new System.Drawing.Size(224, 84);
            this.listBox_Prato_Vegan.TabIndex = 55;
            // 
            // Pratos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.listBox_Prato_Vegan);
            this.Controls.Add(this.listBox_Prato_Peixe);
            this.Controls.Add(this.listBox_Prato_Carne);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_Apagar_Peixe);
            this.Controls.Add(this.button_Apagar_Vegan);
            this.Controls.Add(this.button_Apagar_Carne);
            this.Controls.Add(this.button_Editar_Peixe);
            this.Controls.Add(this.button_Editar_Vegan);
            this.Controls.Add(this.button_Editar_Carne);
            this.Controls.Add(this.button_Adicionar_Peixe);
            this.Controls.Add(this.button_Adicionar_Vegan);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button_Adicionar_Carne);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Pratos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pratos";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button_Adicionar_Carne;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Adicionar_Vegan;
        private System.Windows.Forms.Button button_Adicionar_Peixe;
        private System.Windows.Forms.Button button_Editar_Carne;
        private System.Windows.Forms.Button button_Editar_Vegan;
        private System.Windows.Forms.Button button_Editar_Peixe;
        private System.Windows.Forms.Button button_Apagar_Carne;
        private System.Windows.Forms.Button button_Apagar_Vegan;
        private System.Windows.Forms.Button button_Apagar_Peixe;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListBox listBox_Prato_Carne;
        private System.Windows.Forms.ListBox listBox_Prato_Peixe;
        private System.Windows.Forms.ListBox listBox_Prato_Vegan;
    }
}