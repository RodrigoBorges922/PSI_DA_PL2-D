﻿namespace Projeto_DA
{
    partial class FormularioPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormularioPrincipal));
            this.label_Trocar_Funcionario = new System.Windows.Forms.Label();
            this.button_Pratos = new System.Windows.Forms.Button();
            this.textBox_Introducao = new System.Windows.Forms.TextBox();
            this.button_Extras = new System.Windows.Forms.Button();
            this.button_Menus = new System.Windows.Forms.Button();
            this.button_Multas = new System.Windows.Forms.Button();
            this.button_Reservas = new System.Windows.Forms.Button();
            this.button_Clientes = new System.Windows.Forms.Button();
            this.button_Funcionarios = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Previous = new System.Windows.Forms.Button();
            this.button_Next = new System.Windows.Forms.Button();
            this.label_Semanas = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label_Trocar_Funcionario
            // 
            this.label_Trocar_Funcionario.AutoSize = true;
            this.label_Trocar_Funcionario.BackColor = System.Drawing.Color.Transparent;
            this.label_Trocar_Funcionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Trocar_Funcionario.Font = new System.Drawing.Font("Book Antiqua", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Trocar_Funcionario.Location = new System.Drawing.Point(804, 88);
            this.label_Trocar_Funcionario.Name = "label_Trocar_Funcionario";
            this.label_Trocar_Funcionario.Size = new System.Drawing.Size(208, 24);
            this.label_Trocar_Funcionario.TabIndex = 0;
            this.label_Trocar_Funcionario.Text = "Trocar de Funcionário";
            // 
            // button_Pratos
            // 
            this.button_Pratos.Location = new System.Drawing.Point(233, 156);
            this.button_Pratos.Name = "button_Pratos";
            this.button_Pratos.Size = new System.Drawing.Size(75, 23);
            this.button_Pratos.TabIndex = 1;
            this.button_Pratos.Text = "Pratos";
            this.button_Pratos.UseVisualStyleBackColor = true;
            this.button_Pratos.Click += new System.EventHandler(this.button_Pratos_Click);
            // 
            // textBox_Introducao
            // 
            this.textBox_Introducao.BackColor = System.Drawing.Color.White;
            this.textBox_Introducao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Introducao.Font = new System.Drawing.Font("Book Antiqua", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Introducao.Location = new System.Drawing.Point(142, 203);
            this.textBox_Introducao.Multiline = true;
            this.textBox_Introducao.Name = "textBox_Introducao";
            this.textBox_Introducao.Size = new System.Drawing.Size(756, 325);
            this.textBox_Introducao.TabIndex = 2;
            this.textBox_Introducao.Text = resources.GetString("textBox_Introducao.Text");
            this.textBox_Introducao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_Extras
            // 
            this.button_Extras.Location = new System.Drawing.Point(314, 156);
            this.button_Extras.Name = "button_Extras";
            this.button_Extras.Size = new System.Drawing.Size(75, 23);
            this.button_Extras.TabIndex = 3;
            this.button_Extras.Text = "Extras";
            this.button_Extras.UseVisualStyleBackColor = true;
            this.button_Extras.Click += new System.EventHandler(this.button_Extras_Click);
            // 
            // button_Menus
            // 
            this.button_Menus.Location = new System.Drawing.Point(395, 156);
            this.button_Menus.Name = "button_Menus";
            this.button_Menus.Size = new System.Drawing.Size(75, 23);
            this.button_Menus.TabIndex = 4;
            this.button_Menus.Text = "Menus";
            this.button_Menus.UseVisualStyleBackColor = true;
            this.button_Menus.Click += new System.EventHandler(this.button_Menu_Click);
            // 
            // button_Multas
            // 
            this.button_Multas.Location = new System.Drawing.Point(476, 156);
            this.button_Multas.Name = "button_Multas";
            this.button_Multas.Size = new System.Drawing.Size(75, 23);
            this.button_Multas.TabIndex = 5;
            this.button_Multas.Text = "Multas";
            this.button_Multas.UseVisualStyleBackColor = true;
            this.button_Multas.Click += new System.EventHandler(this.button_Multas_Click);
            // 
            // button_Reservas
            // 
            this.button_Reservas.Location = new System.Drawing.Point(557, 156);
            this.button_Reservas.Name = "button_Reservas";
            this.button_Reservas.Size = new System.Drawing.Size(75, 23);
            this.button_Reservas.TabIndex = 6;
            this.button_Reservas.Text = "Reservas";
            this.button_Reservas.UseVisualStyleBackColor = true;
            this.button_Reservas.Click += new System.EventHandler(this.button_Reservas_Click);
            // 
            // button_Clientes
            // 
            this.button_Clientes.Location = new System.Drawing.Point(638, 156);
            this.button_Clientes.Name = "button_Clientes";
            this.button_Clientes.Size = new System.Drawing.Size(75, 23);
            this.button_Clientes.TabIndex = 7;
            this.button_Clientes.Text = "Clientes";
            this.button_Clientes.UseVisualStyleBackColor = true;
            this.button_Clientes.Click += new System.EventHandler(this.button_Clientes_Click);
            // 
            // button_Funcionarios
            // 
            this.button_Funcionarios.Location = new System.Drawing.Point(719, 156);
            this.button_Funcionarios.Name = "button_Funcionarios";
            this.button_Funcionarios.Size = new System.Drawing.Size(75, 23);
            this.button_Funcionarios.TabIndex = 8;
            this.button_Funcionarios.Text = "Funcionários";
            this.button_Funcionarios.UseVisualStyleBackColor = true;
            this.button_Funcionarios.Click += new System.EventHandler(this.button_Funcionarios_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(142, 412);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(756, 199);
            this.listBox1.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-22, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1094, 36);
            this.panel1.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(480, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 24);
            this.label7.TabIndex = 1;
            this.label7.Text = "Página Inicial";
            // 
            // button_Previous
            // 
            this.button_Previous.Location = new System.Drawing.Point(395, 365);
            this.button_Previous.Name = "button_Previous";
            this.button_Previous.Size = new System.Drawing.Size(64, 23);
            this.button_Previous.TabIndex = 30;
            this.button_Previous.Text = "<";
            this.button_Previous.UseVisualStyleBackColor = true;
            this.button_Previous.Click += new System.EventHandler(this.button_Previous_Click);
            // 
            // button_Next
            // 
            this.button_Next.Location = new System.Drawing.Point(586, 365);
            this.button_Next.Name = "button_Next";
            this.button_Next.Size = new System.Drawing.Size(65, 23);
            this.button_Next.TabIndex = 31;
            this.button_Next.Text = ">";
            this.button_Next.UseVisualStyleBackColor = true;
            this.button_Next.Click += new System.EventHandler(this.button_Next_Click);
            // 
            // label_Semanas
            // 
            this.label_Semanas.AutoSize = true;
            this.label_Semanas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Semanas.Location = new System.Drawing.Point(476, 364);
            this.label_Semanas.Name = "label_Semanas";
            this.label_Semanas.Size = new System.Drawing.Size(95, 24);
            this.label_Semanas.TabIndex = 32;
            this.label_Semanas.Text = "Semana 1";
            this.label_Semanas.Click += new System.EventHandler(this.label_Semanas_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormularioPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.label_Semanas);
            this.Controls.Add(this.button_Next);
            this.Controls.Add(this.button_Previous);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label_Trocar_Funcionario);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_Funcionarios);
            this.Controls.Add(this.button_Clientes);
            this.Controls.Add(this.button_Reservas);
            this.Controls.Add(this.button_Multas);
            this.Controls.Add(this.button_Menus);
            this.Controls.Add(this.button_Extras);
            this.Controls.Add(this.textBox_Introducao);
            this.Controls.Add(this.button_Pratos);
            this.Name = "FormularioPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCantina";
            this.Load += new System.EventHandler(this.FormularioPrincipal_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Trocar_Funcionario;
        private System.Windows.Forms.Button button_Pratos;
        private System.Windows.Forms.TextBox textBox_Introducao;
        private System.Windows.Forms.Button button_Extras;
        private System.Windows.Forms.Button button_Menus;
        private System.Windows.Forms.Button button_Multas;
        private System.Windows.Forms.Button button_Reservas;
        private System.Windows.Forms.Button button_Clientes;
        private System.Windows.Forms.Button button_Funcionarios;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_Previous;
        private System.Windows.Forms.Button button_Next;
        private System.Windows.Forms.Label label_Semanas;
        private System.Windows.Forms.Label label7;
    }
}

