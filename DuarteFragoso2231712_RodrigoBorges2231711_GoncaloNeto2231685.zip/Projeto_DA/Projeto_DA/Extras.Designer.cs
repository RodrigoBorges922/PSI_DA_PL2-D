﻿namespace Projeto_DA
{
    partial class Extras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Apagar_Extra = new System.Windows.Forms.Button();
            this.button_Editar_Extra = new System.Windows.Forms.Button();
            this.button_Adicionar_Extra = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.listBox_Extras = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-22, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1061, 36);
            this.panel1.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(500, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "Extras";
            // 
            // button_Apagar_Extra
            // 
            this.button_Apagar_Extra.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Extra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Extra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Extra.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Extra.Location = new System.Drawing.Point(746, 351);
            this.button_Apagar_Extra.Name = "button_Apagar_Extra";
            this.button_Apagar_Extra.Size = new System.Drawing.Size(142, 52);
            this.button_Apagar_Extra.TabIndex = 52;
            this.button_Apagar_Extra.Text = "Apagar";
            this.button_Apagar_Extra.UseVisualStyleBackColor = false;
            this.button_Apagar_Extra.Click += new System.EventHandler(this.button_Apagar_Extra_Click);
            // 
            // button_Editar_Extra
            // 
            this.button_Editar_Extra.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Extra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Extra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Extra.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Extra.Location = new System.Drawing.Point(746, 293);
            this.button_Editar_Extra.Name = "button_Editar_Extra";
            this.button_Editar_Extra.Size = new System.Drawing.Size(142, 52);
            this.button_Editar_Extra.TabIndex = 51;
            this.button_Editar_Extra.Text = "Editar";
            this.button_Editar_Extra.UseVisualStyleBackColor = false;
            this.button_Editar_Extra.Click += new System.EventHandler(this.button_Editar_Extra_Click);
            // 
            // button_Adicionar_Extra
            // 
            this.button_Adicionar_Extra.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Extra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Extra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Extra.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Extra.Location = new System.Drawing.Point(746, 235);
            this.button_Adicionar_Extra.Name = "button_Adicionar_Extra";
            this.button_Adicionar_Extra.Size = new System.Drawing.Size(142, 52);
            this.button_Adicionar_Extra.TabIndex = 50;
            this.button_Adicionar_Extra.Text = "Adicionar";
            this.button_Adicionar_Extra.UseVisualStyleBackColor = false;
            this.button_Adicionar_Extra.Click += new System.EventHandler(this.button_Adicionar_Carne_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Projeto_DA.Properties.Resources.homepage1;
            this.pictureBox2.Location = new System.Drawing.Point(931, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 54;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // listBox_Extras
            // 
            this.listBox_Extras.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Extras.FormattingEnabled = true;
            this.listBox_Extras.ItemHeight = 24;
            this.listBox_Extras.Location = new System.Drawing.Point(64, 235);
            this.listBox_Extras.Name = "listBox_Extras";
            this.listBox_Extras.Size = new System.Drawing.Size(407, 268);
            this.listBox_Extras.TabIndex = 55;
            this.listBox_Extras.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Extras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.listBox_Extras);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_Apagar_Extra);
            this.Controls.Add(this.button_Editar_Extra);
            this.Controls.Add(this.button_Adicionar_Extra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Extras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Extras";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_Apagar_Extra;
        private System.Windows.Forms.Button button_Editar_Extra;
        private System.Windows.Forms.Button button_Adicionar_Extra;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListBox listBox_Extras;
    }
}