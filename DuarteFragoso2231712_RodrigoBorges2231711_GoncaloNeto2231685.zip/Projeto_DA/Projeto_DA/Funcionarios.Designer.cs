﻿namespace Projeto_DA
{
    partial class Funcionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Apagar_Funcionario = new System.Windows.Forms.Button();
            this.button_Editar_Funcionario = new System.Windows.Forms.Button();
            this.button_Adicionar_Funcionario = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.listBox_Funcionarios = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button_Apagar_Funcionario
            // 
            this.button_Apagar_Funcionario.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Funcionario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Funcionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Funcionario.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Funcionario.Location = new System.Drawing.Point(838, 353);
            this.button_Apagar_Funcionario.Name = "button_Apagar_Funcionario";
            this.button_Apagar_Funcionario.Size = new System.Drawing.Size(109, 67);
            this.button_Apagar_Funcionario.TabIndex = 58;
            this.button_Apagar_Funcionario.Text = "Apagar";
            this.button_Apagar_Funcionario.UseVisualStyleBackColor = false;
            this.button_Apagar_Funcionario.Click += new System.EventHandler(this.button_Apagar_Funcionario_Click);
            // 
            // button_Editar_Funcionario
            // 
            this.button_Editar_Funcionario.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Funcionario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Funcionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Funcionario.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Funcionario.Location = new System.Drawing.Point(838, 280);
            this.button_Editar_Funcionario.Name = "button_Editar_Funcionario";
            this.button_Editar_Funcionario.Size = new System.Drawing.Size(109, 67);
            this.button_Editar_Funcionario.TabIndex = 57;
            this.button_Editar_Funcionario.Text = "Editar";
            this.button_Editar_Funcionario.UseVisualStyleBackColor = false;
            this.button_Editar_Funcionario.Click += new System.EventHandler(this.button_Editar_Funcionario_Click);
            // 
            // button_Adicionar_Funcionario
            // 
            this.button_Adicionar_Funcionario.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Funcionario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Funcionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Funcionario.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Funcionario.Location = new System.Drawing.Point(838, 207);
            this.button_Adicionar_Funcionario.Name = "button_Adicionar_Funcionario";
            this.button_Adicionar_Funcionario.Size = new System.Drawing.Size(109, 67);
            this.button_Adicionar_Funcionario.TabIndex = 56;
            this.button_Adicionar_Funcionario.Text = "Adicionar";
            this.button_Adicionar_Funcionario.UseVisualStyleBackColor = false;
            this.button_Adicionar_Funcionario.Click += new System.EventHandler(this.button_Adicionar_Funcionario_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-21, 111);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1061, 36);
            this.panel1.TabIndex = 55;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(475, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "Funcionários";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 54;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Projeto_DA.Properties.Resources.homepage1;
            this.pictureBox2.Location = new System.Drawing.Point(931, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 60;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // listBox_Funcionarios
            // 
            this.listBox_Funcionarios.BackColor = System.Drawing.Color.Red;
            this.listBox_Funcionarios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listBox_Funcionarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Funcionarios.ForeColor = System.Drawing.Color.White;
            this.listBox_Funcionarios.FormattingEnabled = true;
            this.listBox_Funcionarios.ItemHeight = 20;
            this.listBox_Funcionarios.Location = new System.Drawing.Point(40, 207);
            this.listBox_Funcionarios.Name = "listBox_Funcionarios";
            this.listBox_Funcionarios.Size = new System.Drawing.Size(441, 324);
            this.listBox_Funcionarios.TabIndex = 61;
            // 
            // Funcionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.listBox_Funcionarios);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_Apagar_Funcionario);
            this.Controls.Add(this.button_Editar_Funcionario);
            this.Controls.Add(this.button_Adicionar_Funcionario);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Funcionarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Funcionarios";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_Apagar_Funcionario;
        private System.Windows.Forms.Button button_Editar_Funcionario;
        private System.Windows.Forms.Button button_Adicionar_Funcionario;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListBox listBox_Funcionarios;
    }
}