﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Projeto_DA
{
    public partial class Extras : Form
    {
        string connectionString = String.Format(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\rodri\Desktop\Projeto_DA\Projeto_DA\Database1.mdf;Integrated Security = True");
        public Extras()
        {
            InitializeComponent();
            LoadDataIntoListBox_Extras();
        }

        private void LoadDataIntoListBox_Extras()
        {

            listBox_Extras.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Descricao, Preco FROM Extras";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string descricao = reader["Descricao"].ToString();
                        decimal preco = (decimal)reader["Preco"];
                        listBox_Extras.Items.Add($"{descricao} - {preco:C}");
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Adicionar_Carne_Click(object sender, EventArgs e)
        {
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Nome e Preço";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150 };

            Label lblPrice = new Label() { Left = 10, Top = 60, Text = "Preço (€)" };
            TextBox txtPrice = new TextBox() { Left = 110, Top = 60, Width = 150 };

            txtPrice.KeyPress += new KeyPressEventHandler(txtPrice_KeyPress);

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "INSERT INTO Extras (Descricao, Preco) VALUES (@Name, @Price)";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Price", decimal.Parse(txtPrice.Text));

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Item adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Extras(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível adicionar o item.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao inserir o item: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblPrice);
            popup.Controls.Add(txtPrice);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }


        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permitir apenas números, ponto decimal e teclas de controle (como Backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignora o caractere digitado
            }

            // Permitir apenas um ponto decimal
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true; // Ignora o segundo ponto decimal
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_Apagar_Extra_Click(object sender, EventArgs e)
        {
            if (listBox_Extras.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um extra para apagar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedItem = listBox_Extras.SelectedItem.ToString();
            // Extrair a descrição do item selecionado
            string descricao = selectedItem.Substring(11, selectedItem.IndexOf(", Preço:") - 11);

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Extras WHERE Descricao = @Descricao";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Descricao", descricao);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Extra apagado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDataIntoListBox_Extras(); // Atualizar a lista de itens
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível apagar o extra!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocorreu um erro ao apagar o extra: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_Editar_Extra_Click(object sender, EventArgs e)
        {
            if (listBox_Extras.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione um extra para editar.", "Erro de Seleção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedItem = listBox_Extras.SelectedItem.ToString();
            // Extrair a descrição e o preço do item selecionado
            string descricao = selectedItem.Substring(11, selectedItem.IndexOf(", Preço:") - 11);
            decimal preco = decimal.Parse(selectedItem.Substring(selectedItem.IndexOf("Preço:") + 7).Replace("€", "").Trim());

            // Abrir um formulário de edição com os dados do item selecionado
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 200;
            popup.Text = "Editar Nome e Preço";

            Label label_Name = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox text_Name = new TextBox() { Left = 110, Top = 20, Width = 150, Text = descricao };

            Label lblPrice = new Label() { Left = 10, Top = 60, Text = "Preço (€)" };
            TextBox txtPrice = new TextBox() { Left = 110, Top = 60, Width = 150, Text = preco.ToString() };

            txtPrice.KeyPress += new KeyPressEventHandler(txtPrice_KeyPress);

            Button btnOk = new Button() { Text = "OK", Left = 100, Width = 80, Top = 100 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(text_Name.Text) || string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    MessageBox.Show("Por favor, preencha ambos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL para atualizar o item
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "UPDATE Extras SET Descricao = @Name, Preco = @Price WHERE Descricao = @OldName";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Name", text_Name.Text);
                        command.Parameters.AddWithValue("@Price", decimal.Parse(txtPrice.Text));
                        command.Parameters.AddWithValue("@OldName", descricao);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Extra editado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Extras(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível editar o extra.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao editar o extra: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(label_Name);
            popup.Controls.Add(text_Name);
            popup.Controls.Add(lblPrice);
            popup.Controls.Add(txtPrice);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }
    }
}