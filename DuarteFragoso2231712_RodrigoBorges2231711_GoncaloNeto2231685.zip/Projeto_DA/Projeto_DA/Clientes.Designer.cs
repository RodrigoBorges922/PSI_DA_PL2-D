﻿namespace Projeto_DA
{
    partial class Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_Apagar_Cliente = new System.Windows.Forms.Button();
            this.button_Editar_Cliente = new System.Windows.Forms.Button();
            this.button_Adicionar_Cliente = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.listBox_Clientes = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_Ordenar = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-22, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1094, 36);
            this.panel1.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(500, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 24);
            this.label7.TabIndex = 32;
            this.label7.Text = "Clientes";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button_Apagar_Cliente
            // 
            this.button_Apagar_Cliente.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Cliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Cliente.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Cliente.Location = new System.Drawing.Point(843, 333);
            this.button_Apagar_Cliente.Name = "button_Apagar_Cliente";
            this.button_Apagar_Cliente.Size = new System.Drawing.Size(97, 57);
            this.button_Apagar_Cliente.TabIndex = 62;
            this.button_Apagar_Cliente.Text = "Apagar";
            this.button_Apagar_Cliente.UseVisualStyleBackColor = false;
            this.button_Apagar_Cliente.Click += new System.EventHandler(this.button_Apagar_Cliente_Click);
            // 
            // button_Editar_Cliente
            // 
            this.button_Editar_Cliente.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Cliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Cliente.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Cliente.Location = new System.Drawing.Point(843, 270);
            this.button_Editar_Cliente.Name = "button_Editar_Cliente";
            this.button_Editar_Cliente.Size = new System.Drawing.Size(97, 57);
            this.button_Editar_Cliente.TabIndex = 61;
            this.button_Editar_Cliente.Text = "Editar";
            this.button_Editar_Cliente.UseVisualStyleBackColor = false;
            this.button_Editar_Cliente.Click += new System.EventHandler(this.button_Editar_Cliente_Click);
            // 
            // button_Adicionar_Cliente
            // 
            this.button_Adicionar_Cliente.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Cliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Cliente.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Cliente.Location = new System.Drawing.Point(843, 207);
            this.button_Adicionar_Cliente.Name = "button_Adicionar_Cliente";
            this.button_Adicionar_Cliente.Size = new System.Drawing.Size(97, 57);
            this.button_Adicionar_Cliente.TabIndex = 60;
            this.button_Adicionar_Cliente.Text = "Adicionar";
            this.button_Adicionar_Cliente.UseVisualStyleBackColor = false;
            this.button_Adicionar_Cliente.Click += new System.EventHandler(this.button_Adicionar_Cliente_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Projeto_DA.Properties.Resources.homepage1;
            this.pictureBox2.Location = new System.Drawing.Point(931, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 64;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // listBox_Clientes
            // 
            this.listBox_Clientes.BackColor = System.Drawing.Color.Red;
            this.listBox_Clientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listBox_Clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Clientes.ForeColor = System.Drawing.Color.White;
            this.listBox_Clientes.FormattingEnabled = true;
            this.listBox_Clientes.ItemHeight = 18;
            this.listBox_Clientes.Location = new System.Drawing.Point(42, 207);
            this.listBox_Clientes.Name = "listBox_Clientes";
            this.listBox_Clientes.Size = new System.Drawing.Size(540, 382);
            this.listBox_Clientes.TabIndex = 65;
            this.listBox_Clientes.SelectedIndexChanged += new System.EventHandler(this.listBox_Clientes_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(364, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 16);
            this.label1.TabIndex = 67;
            this.label1.Text = "Organizar por:";
            // 
            // comboBox_Ordenar
            // 
            this.comboBox_Ordenar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Ordenar.FormattingEnabled = true;
            this.comboBox_Ordenar.Items.AddRange(new object[] {
            "Nome",
            "Estudante",
            "Professor"});
            this.comboBox_Ordenar.Location = new System.Drawing.Point(461, 180);
            this.comboBox_Ordenar.Name = "comboBox_Ordenar";
            this.comboBox_Ordenar.Size = new System.Drawing.Size(121, 24);
            this.comboBox_Ordenar.TabIndex = 66;
            // 
            // Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_Ordenar);
            this.Controls.Add(this.listBox_Clientes);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_Apagar_Cliente);
            this.Controls.Add(this.button_Editar_Cliente);
            this.Controls.Add(this.button_Adicionar_Cliente);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Clientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Clientes";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_Apagar_Cliente;
        private System.Windows.Forms.Button button_Editar_Cliente;
        private System.Windows.Forms.Button button_Adicionar_Cliente;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ListBox listBox_Clientes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_Ordenar;
    }
}