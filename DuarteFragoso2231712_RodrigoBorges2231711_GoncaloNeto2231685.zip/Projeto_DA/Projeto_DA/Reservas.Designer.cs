﻿namespace Projeto_DA
{
    partial class Reservas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBox_Carne = new System.Windows.Forms.CheckBox();
            this.checkBox_Peixe = new System.Windows.Forms.CheckBox();
            this.checkBox_Vegan = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_NumEstudante = new System.Windows.Forms.TextBox();
            this.button_ConfirmarReserva = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton_Estudante = new System.Windows.Forms.RadioButton();
            this.radioButton_Professor = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.checkedListBox_Extras_Reserva = new System.Windows.Forms.CheckedListBox();
            this.listBox_Menu_Carne = new System.Windows.Forms.ListBox();
            this.listBox_Menu_Peixe = new System.Windows.Forms.ListBox();
            this.listBox_Menu_Vegan = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // checkBox_Carne
            // 
            this.checkBox_Carne.AutoSize = true;
            this.checkBox_Carne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_Carne.Location = new System.Drawing.Point(82, 164);
            this.checkBox_Carne.Name = "checkBox_Carne";
            this.checkBox_Carne.Size = new System.Drawing.Size(125, 24);
            this.checkBox_Carne.TabIndex = 11;
            this.checkBox_Carne.Text = "Menu Carne";
            this.checkBox_Carne.UseVisualStyleBackColor = true;
            // 
            // checkBox_Peixe
            // 
            this.checkBox_Peixe.AutoSize = true;
            this.checkBox_Peixe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_Peixe.Location = new System.Drawing.Point(82, 307);
            this.checkBox_Peixe.Name = "checkBox_Peixe";
            this.checkBox_Peixe.Size = new System.Drawing.Size(120, 24);
            this.checkBox_Peixe.TabIndex = 13;
            this.checkBox_Peixe.Text = "Menu Peixe";
            this.checkBox_Peixe.UseVisualStyleBackColor = true;
            // 
            // checkBox_Vegan
            // 
            this.checkBox_Vegan.AutoSize = true;
            this.checkBox_Vegan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_Vegan.Location = new System.Drawing.Point(82, 456);
            this.checkBox_Vegan.Name = "checkBox_Vegan";
            this.checkBox_Vegan.Size = new System.Drawing.Size(129, 24);
            this.checkBox_Vegan.TabIndex = 15;
            this.checkBox_Vegan.Text = "Menu Vegan";
            this.checkBox_Vegan.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(596, 311);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "Tipo de Cliente";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(596, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 22;
            this.label4.Text = "Extras";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(596, 456);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(200, 20);
            this.label5.TabIndex = 23;
            this.label5.Text = "Nº do estudante/Professor:";
            // 
            // textBox_NumEstudante
            // 
            this.textBox_NumEstudante.Location = new System.Drawing.Point(802, 456);
            this.textBox_NumEstudante.Name = "textBox_NumEstudante";
            this.textBox_NumEstudante.Size = new System.Drawing.Size(177, 20);
            this.textBox_NumEstudante.TabIndex = 24;
            // 
            // button_ConfirmarReserva
            // 
            this.button_ConfirmarReserva.BackColor = System.Drawing.Color.Red;
            this.button_ConfirmarReserva.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ConfirmarReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ConfirmarReserva.ForeColor = System.Drawing.Color.White;
            this.button_ConfirmarReserva.Location = new System.Drawing.Point(731, 531);
            this.button_ConfirmarReserva.Name = "button_ConfirmarReserva";
            this.button_ConfirmarReserva.Size = new System.Drawing.Size(183, 58);
            this.button_ConfirmarReserva.TabIndex = 27;
            this.button_ConfirmarReserva.Text = "Confirmar Reserva";
            this.button_ConfirmarReserva.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-22, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1061, 36);
            this.panel1.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(500, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "Reservas";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Red;
            this.panel2.Location = new System.Drawing.Point(494, 146);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(50, 524);
            this.panel2.TabIndex = 29;
            // 
            // radioButton_Estudante
            // 
            this.radioButton_Estudante.AutoSize = true;
            this.radioButton_Estudante.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Estudante.Location = new System.Drawing.Point(600, 337);
            this.radioButton_Estudante.Name = "radioButton_Estudante";
            this.radioButton_Estudante.Size = new System.Drawing.Size(101, 24);
            this.radioButton_Estudante.TabIndex = 30;
            this.radioButton_Estudante.TabStop = true;
            this.radioButton_Estudante.Text = "Estudante";
            this.radioButton_Estudante.UseVisualStyleBackColor = true;
            // 
            // radioButton_Professor
            // 
            this.radioButton_Professor.AutoSize = true;
            this.radioButton_Professor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Professor.Location = new System.Drawing.Point(600, 360);
            this.radioButton_Professor.Name = "radioButton_Professor";
            this.radioButton_Professor.Size = new System.Drawing.Size(95, 24);
            this.radioButton_Professor.TabIndex = 31;
            this.radioButton_Professor.TabStop = true;
            this.radioButton_Professor.Text = "Professor";
            this.radioButton_Professor.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Projeto_DA.Properties.Resources.homepage1;
            this.pictureBox2.Location = new System.Drawing.Point(931, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 53;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // checkedListBox_Extras_Reserva
            // 
            this.checkedListBox_Extras_Reserva.CheckOnClick = true;
            this.checkedListBox_Extras_Reserva.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkedListBox_Extras_Reserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox_Extras_Reserva.FormattingEnabled = true;
            this.checkedListBox_Extras_Reserva.Location = new System.Drawing.Point(600, 191);
            this.checkedListBox_Extras_Reserva.Name = "checkedListBox_Extras_Reserva";
            this.checkedListBox_Extras_Reserva.Size = new System.Drawing.Size(218, 106);
            this.checkedListBox_Extras_Reserva.TabIndex = 55;
            // 
            // listBox_Menu_Carne
            // 
            this.listBox_Menu_Carne.FormattingEnabled = true;
            this.listBox_Menu_Carne.Location = new System.Drawing.Point(82, 194);
            this.listBox_Menu_Carne.Name = "listBox_Menu_Carne";
            this.listBox_Menu_Carne.Size = new System.Drawing.Size(311, 95);
            this.listBox_Menu_Carne.TabIndex = 56;
            // 
            // listBox_Menu_Peixe
            // 
            this.listBox_Menu_Peixe.FormattingEnabled = true;
            this.listBox_Menu_Peixe.Location = new System.Drawing.Point(82, 337);
            this.listBox_Menu_Peixe.Name = "listBox_Menu_Peixe";
            this.listBox_Menu_Peixe.Size = new System.Drawing.Size(311, 95);
            this.listBox_Menu_Peixe.TabIndex = 57;
            // 
            // listBox_Menu_Vegan
            // 
            this.listBox_Menu_Vegan.FormattingEnabled = true;
            this.listBox_Menu_Vegan.Location = new System.Drawing.Point(82, 486);
            this.listBox_Menu_Vegan.Name = "listBox_Menu_Vegan";
            this.listBox_Menu_Vegan.Size = new System.Drawing.Size(311, 95);
            this.listBox_Menu_Vegan.TabIndex = 58;
            // 
            // Reservas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.listBox_Menu_Vegan);
            this.Controls.Add(this.listBox_Menu_Peixe);
            this.Controls.Add(this.listBox_Menu_Carne);
            this.Controls.Add(this.checkedListBox_Extras_Reserva);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.radioButton_Professor);
            this.Controls.Add(this.radioButton_Estudante);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_ConfirmarReserva);
            this.Controls.Add(this.textBox_NumEstudante);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.checkBox_Vegan);
            this.Controls.Add(this.checkBox_Peixe);
            this.Controls.Add(this.checkBox_Carne);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Reservas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reservas";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBox_Carne;
        private System.Windows.Forms.CheckBox checkBox_Peixe;
        private System.Windows.Forms.CheckBox checkBox_Vegan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_NumEstudante;
        private System.Windows.Forms.Button button_ConfirmarReserva;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButton_Estudante;
        private System.Windows.Forms.RadioButton radioButton_Professor;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckedListBox checkedListBox_Extras_Reserva;
        private System.Windows.Forms.ListBox listBox_Menu_Carne;
        private System.Windows.Forms.ListBox listBox_Menu_Peixe;
        private System.Windows.Forms.ListBox listBox_Menu_Vegan;
    }
}