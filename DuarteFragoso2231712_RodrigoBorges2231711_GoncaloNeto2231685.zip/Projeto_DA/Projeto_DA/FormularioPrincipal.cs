﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Projeto_DA
{
    public partial class FormularioPrincipal : Form
    {
        private int currentWeekIndex;
        private string[] weeks;

        public FormularioPrincipal()
        {
            InitializeComponent();
            InitializeWeeks();
        }

        private void button_Pratos_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            Pratos pratosForm = new Pratos();

            // Exibir o formulário de pratos
            pratosForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Extras_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            Extras ExtrasForm = new Extras();

            // Exibir o formulário de pratos
            ExtrasForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Menu_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            Menus MenusForm = new Menus();

            // Exibir o formulário de pratos
            MenusForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Multas_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            Multas MultasForm = new Multas();

            // Exibir o formulário de pratos
            MultasForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Reservas_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            Reservas ReservasForm = new Reservas();

            // Exibir o formulário de pratos
            ReservasForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Clientes_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            Clientes ClientesForm = new Clientes();

            // Exibir o formulário de pratos
            ClientesForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void button_Funcionarios_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            Funcionarios FuncionariosForm = new Funcionarios();

            // Exibir o formulário de pratos
            FuncionariosForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void FormularioPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void InitializeWeeks()
        {
            weeks = new string[]
            {
            "Semana 1", "Semana 2", "Semana 3", "Semana 4", "Semana 5",
            "Semana 6", "Semana 7", "Semana 8", "Semana 9", "Semana 10",
            "Semana 11", "Semana 12", "Semana 13", "Semana 14", "Semana 15",
            "Semana 16", "Semana 17", "Semana 18", "Semana 19", "Semana 20",
            "Semana 21", "Semana 22", "Semana 23", "Semana 24", "Semana 25",
            "Semana 26", "Semana 27", "Semana 28", "Semana 29", "Semana 30",
            "Semana 31", "Semana 32", "Semana 33", "Semana 34", "Semana 35",
            "Semana 36", "Semana 37", "Semana 38", "Semana 39", "Semana 40",
            "Semana 41", "Semana 42", "Semana 43", "Semana 44", "Semana 45",
            "Semana 46", "Semana 47", "Semana 48", "Semana 49", "Semana 50",
            "Semana 51", "Semana 52"
            };
            currentWeekIndex = 0;
        }

        private void button_Previous_Click(object sender, EventArgs e)
        {
            if (currentWeekIndex > 0)
            {
                currentWeekIndex--;
            }
            else
            {
                currentWeekIndex = weeks.Length - 1;
            }
            label_Semanas.Text = weeks[currentWeekIndex];
        }

        private void button_Next_Click(object sender, EventArgs e)
        {
            if (currentWeekIndex < weeks.Length - 1)
            {
                currentWeekIndex++;
            }
            else
            {
                currentWeekIndex = 0;
            }
            label_Semanas.Text = weeks[currentWeekIndex];
        }

        private void label_Semanas_Click(object sender, EventArgs e)
        {
            label_Semanas.Text = weeks[currentWeekIndex];
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
