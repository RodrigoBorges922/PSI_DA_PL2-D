﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DA
{
    public partial class Multas : Form
    {

        string connectionString = String.Format(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\rodri\Desktop\Projeto_DA\Projeto_DA\Database1.mdf;Integrated Security = True");

        public Multas()
        {
            InitializeComponent();
            LoadDataIntoListBox_Multas();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void LoadDataIntoListBox_Multas()
        {
            listBox_Multas.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT id, valor, NumHoras FROM Multas";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string id = reader["id"].ToString();
                        string valor = reader["valor"].ToString();
                        string numHoras = reader["NumHoras"].ToString();
                        listBox_Multas.Items.Add($"Multa de {valor}€ id={id} com {numHoras} hora(s) de atraso");
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_Adicionar_Multa_Click(object sender, EventArgs e)
        {
            Form popup = new Form();
            popup.Width = 300;
            popup.Height = 250;
            popup.Text = "Adicionar Multa";

            Label labelId = new Label() { Left = 20, Top = 20, Text = "ID" };
            TextBox textId = new TextBox() { Left = 120, Top = 20, Width = 150 };

            Label labelValor = new Label() { Left = 20, Top = 60, Text = "Valor" };
            TextBox textValor = new TextBox() { Left = 120, Top = 60, Width = 150 };

            Label labelNumHoras = new Label() { Left = 20, Top = 100, Text = "NumHoras" };
            TextBox textNumHoras = new TextBox() { Left = 120, Top = 100, Width = 150 };

            Button btnOk = new Button() { Text = "OK", Left = 120, Width = 80, Top = 140 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(textId.Text) ||
                    string.IsNullOrWhiteSpace(textValor.Text) ||
                    string.IsNullOrWhiteSpace(textNumHoras.Text))
                {
                    MessageBox.Show("Por favor, preencha todos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Inserir dados na base de dados
                string insertQuery = "INSERT INTO Multas (id, valor, NumHoras) VALUES (@Id, @Valor, @NumHoras)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(insertQuery, connection);
                    command.Parameters.AddWithValue("@Id", textId.Text);
                    command.Parameters.AddWithValue("@Valor", textValor.Text);
                    command.Parameters.AddWithValue("@NumHoras", textNumHoras.Text);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Multa adicionada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Limpar e recarregar a ListBox com as multas atualizadas
                            listBox_Multas.Items.Clear();
                            LoadDataIntoListBox_Multas(); // Método para carregar os dados na ListBox
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível adicionar a multa.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao inserir a multa: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(labelId);
            popup.Controls.Add(textId);
            popup.Controls.Add(labelValor);
            popup.Controls.Add(textValor);
            popup.Controls.Add(labelNumHoras);
            popup.Controls.Add(textNumHoras);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Editar_Multa_Click(object sender, EventArgs e)
        {
            // Verificar se uma multa está selecionada na ListBox
            if (listBox_Multas.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione uma multa para editar.", "Seleção Necessária", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obter a multa selecionada na ListBox
            string multaSelecionada = listBox_Multas.SelectedItem.ToString();

            // Extrair o id da multa da string exibida na ListBox (considerando o formato "Multa de (Valor), id=x com (NumHoras) de atraso")
            string idMulta = multaSelecionada.Split(new string[] { "id=" }, StringSplitOptions.RemoveEmptyEntries)[1].Split(' ')[0];

            // Consultar o banco de dados para obter os detalhes da multa selecionada
            string query = "SELECT * FROM Multas WHERE id = @Id";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", idMulta);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Criar o formulário de edição
                        Form popup = new Form();
                        popup.Width = 300;
                        popup.Height = 250;
                        popup.Text = "Editar Multa";

                        Label labelId = new Label() { Left = 20, Top = 20, Text = "ID" };
                        TextBox textId = new TextBox() { Left = 120, Top = 20, Width = 150, Text = reader["id"].ToString(), ReadOnly = true };

                        Label labelValor = new Label() { Left = 20, Top = 60, Text = "Valor" };
                        TextBox textValor = new TextBox() { Left = 120, Top = 60, Width = 150, Text = reader["valor"].ToString() };

                        Label labelNumHoras = new Label() { Left = 20, Top = 100, Text = "NumHoras" };
                        TextBox textNumHoras = new TextBox() { Left = 120, Top = 100, Width = 150, Text = reader["NumHoras"].ToString() };

                        reader.Close(); // Fechar o reader antes de executar o comando de atualização

                        Button btnOk = new Button() { Text = "OK", Left = 120, Width = 80, Top = 140 };
                        btnOk.Click += (s, ev) =>
                        {
                            // Validar entrada
                            if (string.IsNullOrWhiteSpace(textValor.Text) || string.IsNullOrWhiteSpace(textNumHoras.Text))
                            {
                                MessageBox.Show("Por favor, preencha todos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Validar se os campos Valor e NumHoras são numéricos
                            if (!decimal.TryParse(textValor.Text, out decimal valor) || !int.TryParse(textNumHoras.Text, out int numHoras))
                            {
                                MessageBox.Show("Os campos 'Valor' e 'NumHoras' devem ser numéricos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Atualizar os dados da multa no banco de dados
                            string updateQuery = "UPDATE Multas SET valor = @Valor, NumHoras = @NumHoras WHERE id = @Id";
                            using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                            {
                                updateCommand.Parameters.AddWithValue("@Id", textId.Text);
                                updateCommand.Parameters.AddWithValue("@Valor", valor);
                                updateCommand.Parameters.AddWithValue("@NumHoras", numHoras);

                                try
                                {
                                    int rowsAffected = updateCommand.ExecuteNonQuery();
                                    if (rowsAffected > 0)
                                    {
                                        MessageBox.Show("Multa atualizada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        // Limpar e recarregar a ListBox com as multas atualizadas
                                        listBox_Multas.Items.Clear();
                                        LoadDataIntoListBox_Multas(); // Método para carregar os dados na ListBox
                                    }
                                    else
                                    {
                                        MessageBox.Show("Não foi possível atualizar a multa.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show($"Ocorreu um erro ao atualizar a multa: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }

                                popup.DialogResult = DialogResult.OK;
                                popup.Close();
                            }
                        };

                        popup.Controls.Add(labelId);
                        popup.Controls.Add(textId);
                        popup.Controls.Add(labelValor);
                        popup.Controls.Add(textValor);
                        popup.Controls.Add(labelNumHoras);
                        popup.Controls.Add(textNumHoras);
                        popup.Controls.Add(btnOk);
                        popup.AcceptButton = btnOk;

                        popup.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Multa não encontrada.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocorreu um erro ao buscar os dados da multa: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button_Apagar_Multa_Click(object sender, EventArgs e)
        {
            // Verificar se uma multa está selecionada na ListBox
            if (listBox_Multas.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione uma multa para apagar.", "Seleção Necessária", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obter a multa selecionada na ListBox
            string multaSelecionada = listBox_Multas.SelectedItem.ToString();

            // Extrair o id da multa da string exibida na ListBox (considerando o formato "Multa de (Valor), id=x com (NumHoras) de atraso")
            string idMulta = multaSelecionada.Split(new string[] { "id=" }, StringSplitOptions.RemoveEmptyEntries)[1].Split(' ')[0];

            // Confirmar exclusão
            var confirmResult = MessageBox.Show("Tem certeza que deseja apagar esta multa?", "Confirmação de Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmResult == DialogResult.No)
            {
                return;
            }

            // Apagar a multa do banco de dados
            string deleteQuery = "DELETE FROM Multas WHERE id = @Id";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(deleteQuery, connection);
                command.Parameters.AddWithValue("@Id", idMulta);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Multa apagada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Remover a multa da ListBox
                        listBox_Multas.Items.Remove(multaSelecionada);
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível apagar a multa.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocorreu um erro ao apagar a multa: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
