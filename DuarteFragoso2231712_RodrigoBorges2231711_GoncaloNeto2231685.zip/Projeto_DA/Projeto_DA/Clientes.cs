﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_DA
{
    public partial class Clientes : Form
    {
        string connectionString = String.Format(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\rodri\Desktop\Projeto_DA\Projeto_DA\Database1.mdf;Integrated Security = True");

        public Clientes()
        {
            InitializeComponent();
            comboBox_Ordenar.SelectedIndexChanged += comboBox_Ordenar_SelectedIndexChanged;
            comboBox_Ordenar.DropDownStyle = ComboBoxStyle.DropDownList;
            LoadDataIntoListBox_Clientes();
        }

        private void LoadDataIntoListBox_Clientes()
        {
            listBox_Clientes.Items.Clear(); // Limpar itens existentes

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT nome, email, numero, nif, saldo, tipo FROM Clientes";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        string email = reader["email"].ToString();
                        string numero = reader["numero"].ToString();
                        string nif = reader["nif"].ToString();
                        decimal saldo = (decimal)reader["saldo"];
                        string tipo = reader["tipo"].ToString();
                        listBox_Clientes.Items.Add($"{nome} - {email} - {numero} - {nif} - {saldo:C} - {tipo}");
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox_Ordenar_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedOrder = comboBox_Ordenar.SelectedItem.ToString();
            List<string> clientes = new List<string>();

            // Carregar os itens atuais da listBox_Clientes para a lista clientes
            foreach (var item in listBox_Clientes.Items)
            {
                clientes.Add(item.ToString());
            }

            // Realizar a ordenação baseada na opção selecionada
            switch (selectedOrder)
            {
                case "Nome":
                    clientes = clientes.OrderBy(c => c.Split('-')[0].Trim()).ToList();
                    break;
                case "Estudante":
                    clientes = clientes.OrderBy(c => c.Contains("Estudante") ? 0 : 1).ThenBy(c => c.Split('-')[0].Trim()).ToList();
                    break;
                case "Professor":
                    clientes = clientes.OrderBy(c => c.Contains("Professor") ? 0 : 1).ThenBy(c => c.Split('-')[0].Trim()).ToList();
                    break;
                default:
                    // Caso a opção selecionada não seja válida, saia do método
                    return;
            }

            // Limpar a listbox e adicionar os itens ordenados
            listBox_Clientes.Items.Clear();
            foreach (var cliente in clientes)
            {
                listBox_Clientes.Items.Add(cliente);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Criar uma instância do formulário da página de pratos
            FormularioPrincipal FormularioPrincipalForm = new FormularioPrincipal();

            // Exibir o formulário de pratos
            FormularioPrincipalForm.Show();

            //Esconder o formulário atual
            this.Hide();
        }

        private void listBox_Clientes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_Adicionar_Cliente_Click(object sender, EventArgs e)
        {
            Form popup = new Form();
            popup.Width = 400;
            popup.Height = 350;
            popup.Text = "Adicionar Cliente";

            Label labelNome = new Label() { Left = 10, Top = 20, Text = "Nome" };
            TextBox textNome = new TextBox() { Left = 120, Top = 20, Width = 200 };

            Label labelEmail = new Label() { Left = 10, Top = 60, Text = "Email" };
            TextBox textEmail = new TextBox() { Left = 120, Top = 60, Width = 200 };

            Label labelNumero = new Label() { Left = 10, Top = 100, Text = "Número" };
            TextBox textNumero = new TextBox() { Left = 120, Top = 100, Width = 200 };

            Label labelNIF = new Label() { Left = 10, Top = 140, Text = "NIF" };
            TextBox textNIF = new TextBox() { Left = 120, Top = 140, Width = 200 };

            Label labelSaldo = new Label() { Left = 10, Top = 180, Text = "Saldo" };
            TextBox textSaldo = new TextBox() { Left = 120, Top = 180, Width = 200 };

            Label labelTipo = new Label() { Left = 10, Top = 220, Text = "Tipo" };
            ComboBox comboTipo = new ComboBox() { Left = 120, Top = 220, Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            comboTipo.Items.Add("Estudante");
            comboTipo.Items.Add("Professor");

            Button btnOk = new Button() { Text = "OK", Left = 150, Width = 80, Top = 260 };
            btnOk.Click += (s, ev) =>
            {
                // Validar entrada
                if (string.IsNullOrWhiteSpace(textNome.Text) ||
                    string.IsNullOrWhiteSpace(textEmail.Text) ||
                    string.IsNullOrWhiteSpace(textNumero.Text) ||
                    string.IsNullOrWhiteSpace(textNIF.Text) ||
                    string.IsNullOrWhiteSpace(textSaldo.Text) ||
                    comboTipo.SelectedItem == null)
                {
                    MessageBox.Show("Por favor, preencha todos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validar formato do email usando regex
                if (!Regex.IsMatch(textEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    MessageBox.Show("Por favor, insira um email válido.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validar tamanho do NIF
                if (textNIF.Text.Length != 9)
                {
                    MessageBox.Show("O NIF deve conter exatamente 9 dígitos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validar tamanho do número
                if (textNumero.Text.Length != 7)
                {
                    MessageBox.Show("O número deve conter exatamente 7 dígitos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validar valor do saldo (pode ser 0)
                if (!decimal.TryParse(textSaldo.Text, out decimal saldo) || saldo < 0)
                {
                    MessageBox.Show("Por favor, insira um valor válido para o saldo.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Preparar a conexão e a instrução SQL
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = "INSERT INTO Clientes (nome, email, numero, nif, saldo, tipo) VALUES (@Nome, @Email, @Numero, @NIF, @Saldo, @Tipo)";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@Nome", textNome.Text);
                        command.Parameters.AddWithValue("@Email", textEmail.Text);
                        command.Parameters.AddWithValue("@Numero", textNumero.Text);
                        command.Parameters.AddWithValue("@NIF", textNIF.Text);
                        command.Parameters.AddWithValue("@Saldo", saldo);
                        command.Parameters.AddWithValue("@Tipo", comboTipo.SelectedItem.ToString());

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cliente adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Clientes(); // Atualizar a lista de itens
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível adicionar o cliente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao inserir o cliente: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                popup.DialogResult = DialogResult.OK;
                popup.Close();
            };

            popup.Controls.Add(labelNome);
            popup.Controls.Add(textNome);
            popup.Controls.Add(labelEmail);
            popup.Controls.Add(textEmail);
            popup.Controls.Add(labelNumero);
            popup.Controls.Add(textNumero);
            popup.Controls.Add(labelNIF);
            popup.Controls.Add(textNIF);
            popup.Controls.Add(labelSaldo);
            popup.Controls.Add(textSaldo);
            popup.Controls.Add(labelTipo);
            popup.Controls.Add(comboTipo);
            popup.Controls.Add(btnOk);
            popup.AcceptButton = btnOk;

            popup.ShowDialog();
        }

        private void button_Editar_Cliente_Click(object sender, EventArgs e)
        {
            // Verificar se um cliente está selecionado na ListBox
            if (listBox_Clientes.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione um cliente para editar.", "Seleção Necessária", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obter o cliente selecionado na ListBox
            string clienteSelecionado = listBox_Clientes.SelectedItem.ToString();

            // Extrair o nome do cliente da string exibida na ListBox (considerando um formato "Nome - Email - Número")
            string nomeCliente = clienteSelecionado.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries)[0];

            // Consultar o banco de dados para obter os detalhes do cliente selecionado
            string query = "SELECT * FROM Clientes WHERE nome = @Nome";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nome", nomeCliente);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Criar o formulário de edição
                        Form popup = new Form();
                        popup.Width = 400;
                        popup.Height = 350;
                        popup.Text = "Editar Cliente";

                        Label labelNome = new Label() { Left = 10, Top = 20, Text = "Nome" };
                        TextBox textNome = new TextBox() { Left = 120, Top = 20, Width = 200, Text = reader["nome"].ToString() };

                        Label labelEmail = new Label() { Left = 10, Top = 60, Text = "Email" };
                        TextBox textEmail = new TextBox() { Left = 120, Top = 60, Width = 200, Text = reader["email"].ToString() };

                        Label labelNumero = new Label() { Left = 10, Top = 100, Text = "Número" };
                        TextBox textNumero = new TextBox() { Left = 120, Top = 100, Width = 200, Text = reader["numero"].ToString() };

                        Label labelNIF = new Label() { Left = 10, Top = 140, Text = "NIF" };
                        TextBox textNIF = new TextBox() { Left = 120, Top = 140, Width = 200, Text = reader["nif"].ToString() };

                        Label labelSaldo = new Label() { Left = 10, Top = 180, Text = "Saldo" };
                        TextBox textSaldo = new TextBox() { Left = 120, Top = 180, Width = 200, Text = reader["saldo"].ToString() };

                        Label labelTipo = new Label() { Left = 10, Top = 220, Text = "Tipo" };
                        ComboBox comboTipo = new ComboBox() { Left = 120, Top = 220, Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
                        comboTipo.Items.Add("Estudante");
                        comboTipo.Items.Add("Professor");
                        comboTipo.SelectedItem = reader["tipo"].ToString(); // Selecionar o tipo atual do cliente

                        Button btnOk = new Button() { Text = "OK", Left = 150, Width = 80, Top = 260 };
                        btnOk.Click += (s, ev) =>
                        {
                            // Validar entrada
                            if (string.IsNullOrWhiteSpace(textNome.Text) ||
                                string.IsNullOrWhiteSpace(textEmail.Text) ||
                                string.IsNullOrWhiteSpace(textNumero.Text) ||
                                string.IsNullOrWhiteSpace(textNIF.Text) ||
                                string.IsNullOrWhiteSpace(textSaldo.Text) ||
                                comboTipo.SelectedItem == null)
                            {
                                MessageBox.Show("Por favor, preencha todos os campos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Validar formato do email usando regex
                            if (!Regex.IsMatch(textEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                            {
                                MessageBox.Show("Por favor, insira um email válido.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Validar tamanho do NIF
                            if (textNIF.Text.Length != 9)
                            {
                                MessageBox.Show("O NIF deve conter exatamente 9 dígitos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Validar tamanho do número
                            if (textNumero.Text.Length != 7)
                            {
                                MessageBox.Show("O número deve conter exatamente 7 dígitos.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Validar valor do saldo (pode ser 0)
                            if (!decimal.TryParse(textSaldo.Text, out decimal saldo) || saldo < 0)
                            {
                                MessageBox.Show("Por favor, insira um valor válido para o saldo.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            // Atualizar os dados do cliente no banco de dados
                            string updateQuery = "UPDATE Clientes SET nome = @Nome, email = @Email, numero = @Numero, nif = @NIF, saldo = @Saldo, tipo = @Tipo WHERE nome = @NomeSelecionado";
                            SqlCommand updateCommand = new SqlCommand(updateQuery, connection);
                            updateCommand.Parameters.AddWithValue("@Nome", textNome.Text);
                            updateCommand.Parameters.AddWithValue("@Email", textEmail.Text);
                            updateCommand.Parameters.AddWithValue("@Numero", textNumero.Text);
                            updateCommand.Parameters.AddWithValue("@NIF", textNIF.Text);
                            updateCommand.Parameters.AddWithValue("@Saldo", saldo);
                            updateCommand.Parameters.AddWithValue("@Tipo", comboTipo.SelectedItem.ToString());
                            updateCommand.Parameters.AddWithValue("@NomeSelecionado", nomeCliente);

                            // Fechar o SqlDataReader antes de executar a atualização
                            reader.Close();

                            try
                            {
                                int rowsAffected = updateCommand.ExecuteNonQuery();
                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Cliente atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LoadDataIntoListBox_Clientes(); // Atualizar a lista de clientes
                                }
                                else
                                {
                                    MessageBox.Show("Não foi possível atualizar o cliente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ocorreu um erro ao atualizar o cliente: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            popup.DialogResult = DialogResult.OK;
                            popup.Close();
                        };

                        popup.Controls.Add(labelNome);
                        popup.Controls.Add(textNome);
                        popup.Controls.Add(labelEmail);
                        popup.Controls.Add(textEmail);
                        popup.Controls.Add(labelNumero);
                        popup.Controls.Add(textNumero);
                        popup.Controls.Add(labelNIF);
                        popup.Controls.Add(textNIF);
                        popup.Controls.Add(labelSaldo);
                        popup.Controls.Add(textSaldo);
                        popup.Controls.Add(labelTipo);
                        popup.Controls.Add(comboTipo);
                        popup.Controls.Add(btnOk);
                        popup.AcceptButton = btnOk;

                        popup.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Cliente não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocorreu um erro ao buscar os dados do cliente: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button_Apagar_Cliente_Click(object sender, EventArgs e)
        {
            // Verificar se um cliente está selecionado na ListBox
            if (listBox_Clientes.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecione um cliente para apagar.", "Seleção Necessária", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obter o cliente selecionado na ListBox
            string clienteSelecionado = listBox_Clientes.SelectedItem.ToString();

            // Extrair o nome do cliente da string exibida na ListBox (considerando um formato "Nome - Email - Número")
            string nomeCliente = clienteSelecionado.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries)[0];

            // Confirmar a exclusão com o usuário
            DialogResult dialogResult = MessageBox.Show($"Tem certeza que deseja apagar o cliente '{nomeCliente}'?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                // Executar a exclusão no banco de dados
                string query = "DELETE FROM Clientes WHERE nome = @Nome";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Nome", nomeCliente);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cliente apagado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadDataIntoListBox_Clientes(); // Atualizar a lista de clientes
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível apagar o cliente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocorreu um erro ao apagar o cliente: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
