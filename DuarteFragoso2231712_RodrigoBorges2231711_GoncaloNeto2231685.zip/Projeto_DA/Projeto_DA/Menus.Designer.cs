﻿namespace Projeto_DA
{
    partial class Menus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_Apagar_Menu = new System.Windows.Forms.Button();
            this.button_Editar_Menu = new System.Windows.Forms.Button();
            this.button_Adicionar_Menu = new System.Windows.Forms.Button();
            this.listBox_Menus = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = global::Projeto_DA.Properties.Resources.images;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Location = new System.Drawing.Point(340, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(355, 67);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(-22, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1061, 36);
            this.panel1.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(500, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "Menus";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Projeto_DA.Properties.Resources.homepage1;
            this.pictureBox2.Location = new System.Drawing.Point(931, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 53;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // button_Apagar_Menu
            // 
            this.button_Apagar_Menu.BackColor = System.Drawing.Color.Red;
            this.button_Apagar_Menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Apagar_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Apagar_Menu.ForeColor = System.Drawing.Color.White;
            this.button_Apagar_Menu.Location = new System.Drawing.Point(825, 343);
            this.button_Apagar_Menu.Name = "button_Apagar_Menu";
            this.button_Apagar_Menu.Size = new System.Drawing.Size(97, 57);
            this.button_Apagar_Menu.TabIndex = 65;
            this.button_Apagar_Menu.Text = "Apagar";
            this.button_Apagar_Menu.UseVisualStyleBackColor = false;
            this.button_Apagar_Menu.Click += new System.EventHandler(this.button_Apagar_Menu_Click);
            // 
            // button_Editar_Menu
            // 
            this.button_Editar_Menu.BackColor = System.Drawing.Color.Red;
            this.button_Editar_Menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Editar_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Editar_Menu.ForeColor = System.Drawing.Color.White;
            this.button_Editar_Menu.Location = new System.Drawing.Point(825, 280);
            this.button_Editar_Menu.Name = "button_Editar_Menu";
            this.button_Editar_Menu.Size = new System.Drawing.Size(97, 57);
            this.button_Editar_Menu.TabIndex = 64;
            this.button_Editar_Menu.Text = "Editar";
            this.button_Editar_Menu.UseVisualStyleBackColor = false;
            this.button_Editar_Menu.Click += new System.EventHandler(this.button_Editar_Menu_Click);
            // 
            // button_Adicionar_Menu
            // 
            this.button_Adicionar_Menu.BackColor = System.Drawing.Color.Red;
            this.button_Adicionar_Menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Adicionar_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Adicionar_Menu.ForeColor = System.Drawing.Color.White;
            this.button_Adicionar_Menu.Location = new System.Drawing.Point(825, 217);
            this.button_Adicionar_Menu.Name = "button_Adicionar_Menu";
            this.button_Adicionar_Menu.Size = new System.Drawing.Size(97, 57);
            this.button_Adicionar_Menu.TabIndex = 63;
            this.button_Adicionar_Menu.Text = "Adicionar";
            this.button_Adicionar_Menu.UseVisualStyleBackColor = false;
            this.button_Adicionar_Menu.Click += new System.EventHandler(this.button_Adicionar_Menu_Click);
            // 
            // listBox_Menus
            // 
            this.listBox_Menus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listBox_Menus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_Menus.FormattingEnabled = true;
            this.listBox_Menus.ItemHeight = 16;
            this.listBox_Menus.Location = new System.Drawing.Point(62, 217);
            this.listBox_Menus.Name = "listBox_Menus";
            this.listBox_Menus.Size = new System.Drawing.Size(245, 180);
            this.listBox_Menus.TabIndex = 66;
            // 
            // Menus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 623);
            this.Controls.Add(this.listBox_Menus);
            this.Controls.Add(this.button_Apagar_Menu);
            this.Controls.Add(this.button_Editar_Menu);
            this.Controls.Add(this.button_Adicionar_Menu);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Menus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menus";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button_Apagar_Menu;
        private System.Windows.Forms.Button button_Editar_Menu;
        private System.Windows.Forms.Button button_Adicionar_Menu;
        private System.Windows.Forms.ListBox listBox_Menus;
    }
}